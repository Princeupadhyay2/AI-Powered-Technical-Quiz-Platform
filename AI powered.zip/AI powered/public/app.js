/* ═══════════════════════════════════════════════════════════════════
   TechQuiz Pro v2 — Game Engine
   Dynamic backgrounds · Back buttons · Category themes · AI-powered
   ═══════════════════════════════════════════════════════════════════ */

// ─── State ──────────────────────────────────────────────────────────────────
const state = {
  playerName:    'Player',
  language:      'en',
  category:      'JavaScript',
  difficulty:    'medium',
  questions:     [],
  currentIndex:  0,
  score:         0,
  timerSeconds:  20,
  timerInterval: null,
  startTime:     null,
  answerHistory: [],
};

const TIMER_MAP   = { easy: 10, medium: 20, hard: 30 };
const POINTS_MAP  = { easy: 10, medium: 20, hard: 30 };

// ─── Category Config ─────────────────────────────────────────────────────────
const CAT_CONFIG = {
  'JavaScript':      { icon: '🟨', theme: 'js',     color: '#eab308', label: 'JavaScript',     bg: drawJS    },
  'Python':          { icon: '🐍', theme: 'py',     color: '#3b82f6', label: 'Python',          bg: drawPython},
  'Java':            { icon: '☕', theme: 'java',   color: '#ef4444', label: 'Java',            bg: drawJava  },
  'C++':             { icon: '⚙️', theme: 'cpp',    color: '#8b5cf6', label: 'C++',             bg: drawCpp   },
  'DSA':             { icon: '🌳', theme: 'dsa',    color: '#10b981', label: 'DSA',             bg: drawDSA   },
  'Web Development': { icon: '🌐', theme: 'web',    color: '#ec4899', label: 'Web Dev',         bg: drawWeb   },
  'Database':        { icon: '🗄️', theme: 'db',    color: '#14b8a6', label: 'Database',        bg: drawDB    },
  'AI/ML':           { icon: '🤖', theme: 'ai',     color: '#6366f1', label: 'AI / ML',         bg: drawAI    },
  'DevOps':          { icon: '🚀', theme: 'devops', color: '#f97316', label: 'DevOps',          bg: drawDevOps},
};

// ═══════════════════════════════════════════════════════════════════════════
// CATEGORY BACKGROUND GENERATORS (SVG art per topic)
// ═══════════════════════════════════════════════════════════════════════════
function applyCategoryBg(category) {
  const scene = document.getElementById('catBgScene');
  if (!scene) return;
  scene.innerHTML = '';
  scene.className = 'cat-bg-scene';
  const cfg = CAT_CONFIG[category];
  if (!cfg) return;
  cfg.bg(scene);
  requestAnimationFrame(() => scene.classList.add('visible'));
}

function hideCategoryBg() {
  const scene = document.getElementById('catBgScene');
  if (scene) scene.classList.remove('visible');
}

// ── JavaScript: floating JS tokens & circuit lines ──────────────────────────
function drawJS(el) {
  el.innerHTML = `
  <svg viewBox="0 0 1440 900" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <radialGradient id="jsBg" cx="20%" cy="20%" r="80%">
        <stop offset="0%" stop-color="#1c1000" stop-opacity="0.9"/>
        <stop offset="100%" stop-color="#04040f" stop-opacity="0"/>
      </radialGradient>
    </defs>
    <rect width="1440" height="900" fill="url(#jsBg)"/>
    <!-- Circuit lines -->
    <g stroke="#eab308" stroke-opacity="0.06" stroke-width="1" fill="none">
      <path d="M0,200 H300 V400 H600 V200 H900"/>
      <path d="M200,0 V300 H400 V600 H700 V300 H1000 V0"/>
      <path d="M1440,400 H1100 V150 H800 V400"/>
    </g>
    <!-- Dots at circuit junctions -->
    <g fill="#eab308" opacity="0.15">
      <circle cx="300" cy="200" r="4"/><circle cx="300" cy="400" r="4"/>
      <circle cx="600" cy="400" r="4"/><circle cx="600" cy="200" r="4"/>
      <circle cx="200" cy="300" r="4"/><circle cx="400" cy="300" r="4"/>
      <circle cx="400" cy="600" r="4"/><circle cx="700" cy="600" r="4"/>
      <circle cx="700" cy="300" r="4"/><circle cx="1000" cy="300" r="4"/>
    </g>
    <!-- JS logo watermark -->
    <rect x="60" y="60" width="160" height="160" rx="24" fill="#eab308" opacity="0.05"/>
    <text x="100" y="178" font-family="monospace" font-weight="900" font-size="96" fill="#eab308" opacity="0.07">JS</text>
    <!-- Floating tokens -->
    <text x="900" y="120" font-family="monospace" font-size="18" fill="#eab308" opacity="0.1">const</text>
    <text x="1100" y="300" font-family="monospace" font-size="16" fill="#eab308" opacity="0.09">=&gt;</text>
    <text x="200" y="700" font-family="monospace" font-size="22" fill="#eab308" opacity="0.08">async</text>
    <text x="1200" y="700" font-family="monospace" font-size="20" fill="#eab308" opacity="0.09">{ }</text>
    <text x="650" y="820" font-family="monospace" font-size="16" fill="#eab308" opacity="0.07">Promise</text>
    <!-- Glow blobs -->
    <ellipse cx="100" cy="150" rx="250" ry="200" fill="#eab308" opacity="0.04"/>
    <ellipse cx="1340" cy="750" rx="200" ry="180" fill="#ca8a04" opacity="0.05"/>
  </svg>`;
}

// ── Python: snake coils & brackets ─────────────────────────────────────────
function drawPython(el) {
  el.innerHTML = `
  <svg viewBox="0 0 1440 900" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <radialGradient id="pyBg" cx="80%" cy="80%" r="75%">
        <stop offset="0%" stop-color="#001028" stop-opacity="0.85"/>
        <stop offset="100%" stop-color="#04040f" stop-opacity="0"/>
      </radialGradient>
    </defs>
    <rect width="1440" height="900" fill="url(#pyBg)"/>
    <!-- Hexagonal grid (Python/data science) -->
    <g stroke="#3b82f6" stroke-opacity="0.06" stroke-width="1" fill="none">
      <polygon points="1200,100 1260,134 1260,202 1200,236 1140,202 1140,134"/>
      <polygon points="1300,202 1360,236 1360,304 1300,338 1240,304 1240,236"/>
      <polygon points="1100,202 1160,236 1160,304 1100,338 1040,304 1040,236"/>
      <polygon points="1200,304 1260,338 1260,406 1200,440 1140,406 1140,338"/>
    </g>
    <!-- Python logo snake hint -->
    <path d="M80,200 Q180,100 280,200 Q380,300 480,200" stroke="#3b82f6" stroke-width="6" stroke-opacity="0.08" fill="none" stroke-linecap="round"/>
    <path d="M80,260 Q180,360 280,260 Q380,160 480,260" stroke="#eab308" stroke-width="6" stroke-opacity="0.08" fill="none" stroke-linecap="round"/>
    <!-- Keywords -->
    <text x="900" y="150" font-family="monospace" font-size="20" fill="#3b82f6" opacity="0.1">def</text>
    <text x="1050" y="400" font-family="monospace" font-size="18" fill="#3b82f6" opacity="0.09">lambda</text>
    <text x="200" y="750" font-family="monospace" font-size="22" fill="#eab308" opacity="0.09">class</text>
    <text x="1200" y="800" font-family="monospace" font-size="16" fill="#3b82f6" opacity="0.08">yield</text>
    <text x="650" y="50" font-family="monospace" font-size="18" fill="#3b82f6" opacity="0.09">import</text>
    <!-- Glow -->
    <ellipse cx="1350" cy="800" rx="300" ry="250" fill="#2563eb" opacity="0.05"/>
    <ellipse cx="80"  cy="100" rx="200" ry="160" fill="#3b82f6" opacity="0.05"/>
  </svg>`;
}

// ── Java: coffee rings & class hierarchy ────────────────────────────────────
function drawJava(el) {
  el.innerHTML = `
  <svg viewBox="0 0 1440 900" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
    <rect width="1440" height="900" fill="#0f0000" opacity="0.5"/>
    <!-- Coffee cup rings -->
    <circle cx="1300" cy="180" r="120" stroke="#ef4444" stroke-opacity="0.07" stroke-width="2" fill="none"/>
    <circle cx="1300" cy="180" r="90"  stroke="#ef4444" stroke-opacity="0.05" stroke-width="1" fill="none"/>
    <circle cx="1300" cy="180" r="60"  stroke="#ef4444" stroke-opacity="0.04" stroke-width="1" fill="none"/>
    <!-- Class hierarchy lines -->
    <g stroke="#ef4444" stroke-opacity="0.07" stroke-width="1.5" fill="none">
      <line x1="200" y1="100" x2="200" y2="300"/>
      <line x1="100" y1="300" x2="400" y2="300"/>
      <line x1="100" y1="300" x2="100" y2="500"/>
      <line x1="400" y1="300" x2="400" y2="500"/>
      <line x1="50"  y1="500" x2="200" y2="500"/>
      <line x1="350" y1="500" x2="500" y2="500"/>
    </g>
    <!-- Class boxes -->
    <g fill="none" stroke="#ef4444" stroke-opacity="0.08" stroke-width="1">
      <rect x="150" y="60"  width="100" height="40" rx="6"/>
      <rect x="50"  y="280" width="100" height="40" rx="6"/>
      <rect x="350" y="280" width="100" height="40" rx="6"/>
    </g>
    <!-- Keywords -->
    <text x="850" y="120" font-family="monospace" font-size="18" fill="#ef4444" opacity="0.1">public</text>
    <text x="1050" y="600" font-family="monospace" font-size="16" fill="#ef4444" opacity="0.09">extends</text>
    <text x="200" y="760" font-family="monospace" font-size="20" fill="#ef4444" opacity="0.09">interface</text>
    <text x="1150" y="400" font-family="monospace" font-size="18" fill="#f97316" opacity="0.08">@Override</text>
    <ellipse cx="1350" cy="750" rx="250" ry="200" fill="#ef4444" opacity="0.05"/>
  </svg>`;
}

// ── C++: memory addresses & pointers ────────────────────────────────────────
function drawCpp(el) {
  el.innerHTML = `
  <svg viewBox="0 0 1440 900" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
    <rect width="1440" height="900" fill="#0a0014" opacity="0.6"/>
    <!-- Memory grid -->
    <g stroke="#8b5cf6" stroke-opacity="0.05" stroke-width="1">
      ${[...Array(6)].map((_,i)=>`<rect x="${100+i*200}" y="50" width="160" height="40" rx="4"/>`).join('')}
      ${[...Array(6)].map((_,i)=>`<rect x="${100+i*200}" y="110" width="160" height="40" rx="4"/>`).join('')}
    </g>
    <!-- Pointer arrows -->
    <g stroke="#8b5cf6" stroke-opacity="0.09" stroke-width="1.5" fill="none" marker-end="url(#arrowV)">
      <line x1="180" y1="95" x2="380" y2="95"/>
      <line x1="580" y1="95" x2="780" y2="95"/>
    </g>
    <defs><marker id="arrowV" markerWidth="8" markerHeight="8" refX="4" refY="4" orient="auto">
      <path d="M0,0 L8,4 L0,8 Z" fill="#8b5cf6" opacity="0.4"/>
    </marker></defs>
    <!-- C++ watermark -->
    <text x="900" y="180" font-family="monospace" font-weight="900" font-size="120" fill="#8b5cf6" opacity="0.05">C++</text>
    <!-- Keywords -->
    <text x="80" y="650" font-family="monospace" font-size="18" fill="#8b5cf6" opacity="0.1">template</text>
    <text x="1100" y="200" font-family="monospace" font-size="16" fill="#a78bfa" opacity="0.09">namespace</text>
    <text x="600" y="800" font-family="monospace" font-size="18" fill="#8b5cf6" opacity="0.09">virtual</text>
    <text x="1200" y="700" font-family="monospace" font-size="20" fill="#8b5cf6" opacity="0.08">*ptr</text>
    <ellipse cx="150" cy="750" rx="300" ry="220" fill="#7c3aed" opacity="0.05"/>
  </svg>`;
}

// ── DSA: binary tree nodes ───────────────────────────────────────────────────
function drawDSA(el) {
  el.innerHTML = `
  <svg viewBox="0 0 1440 900" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
    <rect width="1440" height="900" fill="#001408" opacity="0.6"/>
    <!-- Binary tree (right side) -->
    <g stroke="#10b981" stroke-opacity="0.1" stroke-width="1.5" fill="none">
      <!-- Level 1 → 2 -->
      <line x1="1100" y1="120" x2="950"  y2="250"/>
      <line x1="1100" y1="120" x2="1250" y2="250"/>
      <!-- Level 2 → 3 -->
      <line x1="950"  y1="250" x2="870"  y2="380"/>
      <line x1="950"  y1="250" x2="1030" y2="380"/>
      <line x1="1250" y1="250" x2="1170" y2="380"/>
      <line x1="1250" y1="250" x2="1330" y2="380"/>
      <!-- Level 3 → 4 -->
      <line x1="870"  y1="380" x2="830"  y2="500"/>
      <line x1="870"  y1="380" x2="910"  y2="500"/>
      <line x1="1030" y1="380" x2="990"  y2="500"/>
      <line x1="1030" y1="380" x2="1070" y2="500"/>
    </g>
    <g fill="none" stroke="#10b981" stroke-opacity="0.12" stroke-width="1.5">
      <circle cx="1100" cy="120" r="22"/>
      <circle cx="950"  cy="250" r="22"/><circle cx="1250" cy="250" r="22"/>
      <circle cx="870"  cy="380" r="22"/><circle cx="1030" cy="380" r="22"/>
      <circle cx="1170" cy="380" r="22"/><circle cx="1330" cy="380" r="22"/>
    </g>
    <!-- Node values -->
    <g font-family="monospace" font-size="11" fill="#10b981" opacity="0.15" text-anchor="middle">
      <text x="1100" y="124">50</text>
      <text x="950"  y="254">25</text><text x="1250" y="254">75</text>
      <text x="870"  y="384">12</text><text x="1030" y="384">37</text>
      <text x="1170" y="384">62</text><text x="1330" y="384">87</text>
    </g>
    <!-- Keywords left -->
    <text x="60" y="200" font-family="monospace" font-size="18" fill="#10b981" opacity="0.1">O(log n)</text>
    <text x="60" y="400" font-family="monospace" font-size="16" fill="#10b981" opacity="0.09">BFS / DFS</text>
    <text x="60" y="600" font-family="monospace" font-size="18" fill="#10b981" opacity="0.09">hashmap</text>
    <text x="500" y="820" font-family="monospace" font-size="16" fill="#34d399" opacity="0.08">stack · queue</text>
    <ellipse cx="100" cy="800" rx="280" ry="200" fill="#059669" opacity="0.05"/>
  </svg>`;
}

// ── Web Dev: grid layout & HTML tags ────────────────────────────────────────
function drawWeb(el) {
  el.innerHTML = `
  <svg viewBox="0 0 1440 900" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
    <rect width="1440" height="900" fill="#140020" opacity="0.5"/>
    <!-- Browser wireframe -->
    <g fill="none" stroke="#ec4899" stroke-opacity="0.07" stroke-width="1.5">
      <rect x="50" y="50" width="500" height="360" rx="12"/>
      <rect x="50" y="50" width="500" height="40" rx="12"/>
      <rect x="80" y="115" width="440" height="180" rx="6"/>
      <rect x="80" y="310" width="200" height="80" rx="6"/>
      <rect x="300" y="310" width="220" height="80" rx="6"/>
      <!-- browser dots -->
      <circle cx="78" cy="70" r="6"/><circle cx="98" cy="70" r="6"/><circle cx="118" cy="70" r="6"/>
    </g>
    <!-- HTML tags floating -->
    <text x="700" y="100" font-family="monospace" font-size="20" fill="#ec4899" opacity="0.1">&lt;div&gt;</text>
    <text x="1100" y="200" font-family="monospace" font-size="18" fill="#a855f7" opacity="0.09">&lt;section&gt;</text>
    <text x="900" y="500" font-family="monospace" font-size="16" fill="#ec4899" opacity="0.1">&lt;/&gt;</text>
    <text x="200" y="750" font-family="monospace" font-size="18" fill="#ec4899" opacity="0.09">flexbox</text>
    <text x="1200" y="700" font-family="monospace" font-size="20" fill="#a855f7" opacity="0.08">CSS Grid</text>
    <text x="700" y="800" font-family="monospace" font-size="16" fill="#f472b6" opacity="0.09">@media</text>
    <!-- Colorful rainbow glow -->
    <ellipse cx="1400" cy="50"  rx="200" ry="150" fill="#ec4899" opacity="0.06"/>
    <ellipse cx="1400" cy="850" rx="200" ry="150" fill="#a855f7" opacity="0.06"/>
  </svg>`;
}

// ── Database: cylinder stacks & SQL ─────────────────────────────────────────
function drawDB(el) {
  el.innerHTML = `
  <svg viewBox="0 0 1440 900" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
    <rect width="1440" height="900" fill="#001414" opacity="0.55"/>
    <!-- Database cylinders (right) -->
    <g fill="none" stroke="#14b8a6" stroke-opacity="0.1" stroke-width="1.5">
      <ellipse cx="1200" cy="200" rx="100" ry="28"/>
      <line x1="1100" y1="200" x2="1100" y2="360"/>
      <line x1="1300" y1="200" x2="1300" y2="360"/>
      <ellipse cx="1200" cy="360" rx="100" ry="28"/>

      <ellipse cx="1200" cy="440" rx="100" ry="28"/>
      <line x1="1100" y1="440" x2="1100" y2="580"/>
      <line x1="1300" y1="440" x2="1300" y2="580"/>
      <ellipse cx="1200" cy="580" rx="100" ry="28"/>
    </g>
    <!-- Table grid hint -->
    <g stroke="#14b8a6" stroke-opacity="0.06" stroke-width="1">
      <rect x="60" y="80" width="500" height="200" rx="6"/>
      <line x1="60" y1="120" x2="560" y2="120"/>
      <line x1="60" y1="160" x2="560" y2="160"/>
      <line x1="60" y1="200" x2="560" y2="200"/>
      <line x1="60" y1="240" x2="560" y2="240"/>
      <line x1="200" y1="80" x2="200" y2="280"/>
      <line x1="360" y1="80" x2="360" y2="280"/>
    </g>
    <!-- SQL keywords -->
    <text x="700" y="150" font-family="monospace" font-size="20" fill="#14b8a6" opacity="0.11">SELECT *</text>
    <text x="100" y="600" font-family="monospace" font-size="18" fill="#14b8a6" opacity="0.1">JOIN</text>
    <text x="700" y="750" font-family="monospace" font-size="16" fill="#2dd4bf" opacity="0.09">INDEX</text>
    <text x="1050" y="750" font-family="monospace" font-size="18" fill="#14b8a6" opacity="0.09">WHERE</text>
    <ellipse cx="100" cy="850" rx="280" ry="180" fill="#0d9488" opacity="0.05"/>
  </svg>`;
}

// ── AI/ML: neural net nodes ──────────────────────────────────────────────────
function drawAI(el) {
  const layers = [[100,300,500,700], [200,350,500,650,800], [300,450,600], [200,500,800]];
  const xs = [80, 380, 680, 980];
  let lines = '', circles = '';
  layers.forEach((ys, li) => {
    ys.forEach(y => {
      circles += `<circle cx="${xs[li]}" cy="${y}" r="12" fill="none" stroke="#6366f1" stroke-opacity="0.12" stroke-width="1.5"/>`;
      if (li < layers.length - 1) {
        layers[li+1].forEach(y2 => {
          lines += `<line x1="${xs[li]}" y1="${y}" x2="${xs[li+1]}" y2="${y2}" stroke="#6366f1" stroke-opacity="0.04" stroke-width="1"/>`;
        });
      }
    });
  });
  el.innerHTML = `
  <svg viewBox="0 0 1440 900" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
    <rect width="1440" height="900" fill="#020018" opacity="0.65"/>
    <g>${lines}</g><g>${circles}</g>
    <text x="1050" y="200" font-family="monospace" font-size="18" fill="#6366f1" opacity="0.1">model.fit()</text>
    <text x="1100" y="500" font-family="monospace" font-size="16" fill="#818cf8" opacity="0.09">epochs=100</text>
    <text x="1050" y="800" font-family="monospace" font-size="18" fill="#6366f1" opacity="0.1">loss: 0.023</text>
    <text x="500" y="50"  font-family="monospace" font-size="16" fill="#6366f1" opacity="0.1">gradient descent</text>
    <ellipse cx="1380" cy="450" rx="250" ry="350" fill="#4f46e5" opacity="0.05"/>
  </svg>`;
}

// ── DevOps: pipeline & containers ──────────────────────────────────────────
function drawDevOps(el) {
  el.innerHTML = `
  <svg viewBox="0 0 1440 900" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
    <rect width="1440" height="900" fill="#0f0800" opacity="0.55"/>
    <!-- CI/CD Pipeline -->
    <g stroke="#f97316" stroke-opacity="0.09" stroke-width="2" fill="none">
      <line x1="100" y1="200" x2="350" y2="200"/>
      <line x1="350" y1="200" x2="600" y2="200"/>
      <line x1="600" y1="200" x2="850" y2="200"/>
      <line x1="850" y1="200" x2="1100" y2="200"/>
    </g>
    <!-- Pipeline stages -->
    <g fill="none" stroke="#f97316" stroke-opacity="0.1" stroke-width="1.5">
      <rect x="60"  y="170" width="90" height="60" rx="10"/>
      <rect x="310" y="170" width="90" height="60" rx="10"/>
      <rect x="560" y="170" width="90" height="60" rx="10"/>
      <rect x="810" y="170" width="90" height="60" rx="10"/>
      <rect x="1060" y="170" width="90" height="60" rx="10"/>
    </g>
    <!-- Stage labels -->
    <g font-family="monospace" font-size="9" fill="#f97316" opacity="0.12" text-anchor="middle">
      <text x="105"  y="203">BUILD</text><text x="355"  y="203">TEST</text>
      <text x="605"  y="203">SCAN</text> <text x="855"  y="203">DEPLOY</text>
      <text x="1105" y="203">MONITOR</text>
    </g>
    <!-- Docker containers -->
    <g fill="none" stroke="#f97316" stroke-opacity="0.07" stroke-width="1.5">
      <rect x="1100" y="400" width="140" height="100" rx="8"/>
      <rect x="1120" y="380" width="140" height="100" rx="8"/>
      <rect x="1140" y="360" width="140" height="100" rx="8"/>
    </g>
    <text x="100"  y="600" font-family="monospace" font-size="18" fill="#f97316" opacity="0.1">docker run</text>
    <text x="100"  y="780" font-family="monospace" font-size="16" fill="#f97316" opacity="0.09">kubectl apply</text>
    <text x="700"  y="700" font-family="monospace" font-size="18" fill="#fb923c" opacity="0.09">helm install</text>
    <text x="700"  y="50"  font-family="monospace" font-size="16" fill="#f97316" opacity="0.1">git push → CI</text>
    <ellipse cx="200"  cy="800" rx="300" ry="200" fill="#ea580c" opacity="0.05"/>
    <ellipse cx="1300" cy="700" rx="250" ry="200" fill="#f97316" opacity="0.04"/>
  </svg>`;
}

// ═══════════════════════════════════════════════════════════════════════════
// SCREEN MANAGEMENT
// ═══════════════════════════════════════════════════════════════════════════
function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  const el = document.getElementById(id);
  if (el) el.classList.add('active');
}

// ─── Selection Buttons ───────────────────────────────────────────────────────
document.getElementById('langGrid').addEventListener('click', e => {
  const btn = e.target.closest('.lang-btn');
  if (!btn) return;
  document.querySelectorAll('.lang-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  state.language = btn.dataset.lang;
});

document.getElementById('categoryGrid').addEventListener('click', e => {
  const btn = e.target.closest('.cat-btn');
  if (!btn) return;
  document.querySelectorAll('.cat-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  state.category = btn.dataset.cat;
});

document.getElementById('diffGrid').addEventListener('click', e => {
  const btn = e.target.closest('.diff-btn');
  if (!btn) return;
  document.querySelectorAll('.diff-btn').forEach(b => b.classList.remove('active'));
  btn.classList.add('active');
  state.difficulty = btn.dataset.diff;
});

// ═══════════════════════════════════════════════════════════════════════════
// QUIT LOGIC
// ═══════════════════════════════════════════════════════════════════════════
function confirmQuit() {
  clearInterval(state.timerInterval);
  document.getElementById('quitOverlay').classList.remove('hidden');
}
function closeQuit() {
  document.getElementById('quitOverlay').classList.add('hidden');
  // Resume timer
  startTimer(state.questions[state.currentIndex]?.difficulty || state.difficulty, true);
}
function doQuit() {
  document.getElementById('quitOverlay').classList.add('hidden');
  clearInterval(state.timerInterval);
  hideCategoryBg();
  showScreen('screen-home');
}

// ═══════════════════════════════════════════════════════════════════════════
// START GAME
// ═══════════════════════════════════════════════════════════════════════════
async function startGame() {
  const nameInput = document.getElementById('playerName').value.trim();
  state.playerName    = nameInput || 'Anonymous';
  state.score         = 0;
  state.currentIndex  = 0;
  state.answerHistory = [];
  state.startTime     = Date.now();

  showScreen('screen-loading');
  animateLoadingProgress();

  try {
    const res = await fetch(
      `/api/questions?category=${encodeURIComponent(state.category)}&difficulty=${state.difficulty}&language=${state.language}&limit=10&useAI=true`
    );
    const data = await res.json();
    state.questions = (data.success && data.questions.length > 0) ? data.questions : getLocalFallback();
  } catch {
    state.questions = getLocalFallback();
  }

  setTimeout(() => {
    applyCategoryBg(state.category);
    showScreen('screen-quiz');
    renderQuestion();
  }, 1200);
}

// Progress animation
function animateLoadingProgress() {
  const fill = document.getElementById('progressFill');
  const glow = document.getElementById('progressGlow');
  const msgs = [
    'Connecting to Gemini Neural Core...',
    'Synthesizing technical question vectors...',
    'Calibrating algorithmic complexity...',
    'Optimizing interactive challenge...'
  ];
  let p = 0, mIdx = 0;
  const iv = setInterval(() => {
    p = Math.min(p + Math.random() * 14, 92);
    fill.style.width = p + '%';
    if (glow) glow.style.right = (100 - p) + '%';
    if (mIdx < msgs.length && p > (mIdx + 1) * 22) {
      document.getElementById('loadingMsg').textContent = msgs[mIdx++];
    }
  }, 220);
  setTimeout(() => clearInterval(iv), 2500);
}

// ═══════════════════════════════════════════════════════════════════════════
// RENDER QUESTION
// ═══════════════════════════════════════════════════════════════════════════
function renderQuestion() {
  const q = state.questions[state.currentIndex];
  if (!q) { endGame(); return; }

  const cat = q.category || state.category;
  const diff = q.difficulty || state.difficulty;
  const cfg  = CAT_CONFIG[cat] || CAT_CONFIG['JavaScript'];

  // Topbar
  document.getElementById('quizCategory').textContent     = cfg.label || cat;
  const pill = document.getElementById('quizDifficulty');
  pill.textContent = diff.charAt(0).toUpperCase() + diff.slice(1);
  pill.className   = 'diff-pill ' + diff;
  document.getElementById('questionCounter').textContent  = `Q ${state.currentIndex + 1} / ${state.questions.length}`;
  document.getElementById('currentScore').textContent     = state.score;

  // Q number badge
  document.getElementById('qNumText').textContent = String(state.currentIndex + 1).padStart(2, '0');

  // Progress
  document.getElementById('quizProgressFill').style.width =
    (state.currentIndex / state.questions.length * 100) + '%';

  // Category strip inside card
  document.getElementById('qCatIcon').textContent   = cfg.icon;
  document.getElementById('qCatLabel').textContent  = cfg.label || cat;
  document.getElementById('qCatLabel').className    = 'q-cat-label';
  const diffBadge = document.getElementById('qDiffBadge');
  diffBadge.textContent  = diff.charAt(0).toUpperCase() + diff.slice(1);
  diffBadge.className    = 'q-diff-badge diff-pill ' + diff;

  // Themed card border
  document.getElementById('questionCard').className = 'question-card themed theme-' + cfg.theme;

  // Update bg on category change mid-game
  if (cat !== state._lastCat) {
    state._lastCat = cat;
    applyCategoryBg(cat);
  }

  // Question text
  document.getElementById('questionText').innerHTML = formatQuestion(q.question);

  // Options
  const grid = document.getElementById('optionsGrid');
  grid.innerHTML = '';
  const letters = ['A', 'B', 'C', 'D'];
  (q.options || []).forEach((opt, i) => {
    const btn = document.createElement('button');
    btn.className  = 'option-btn';
    btn.id         = `opt-${i}`;
    btn.innerHTML  = `<span class="option-letter">${letters[i]}</span><span class="option-text">${escapeHtml(opt)}</span>`;
    btn.onclick    = () => selectAnswer(i, q.correctAnswer, q.explanation || '');
    grid.appendChild(btn);
  });

  // Hide extras
  document.getElementById('explanationPanel').classList.add('hidden');
  document.getElementById('nextBtn').classList.add('hidden');

  // Track start time of this question for performance graph
  state.qStartTime = Date.now();

  // Timer
  startTimer(diff);
}

// Format question (code blocks)
function formatQuestion(text) {
  if (!text) return '';
  return escapeHtml(text)
    .replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>')
    .replace(/`([^`\n]+)`/g, '<code>$1</code>');
}
function escapeHtml(s) {
  return String(s)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;')
    .replace(/"/g,'&quot;').replace(/'/g,'&#39;');
}

// ═══════════════════════════════════════════════════════════════════════════
// TIMER
// ═══════════════════════════════════════════════════════════════════════════
function startTimer(diff, resume = false) {
  clearInterval(state.timerInterval);
  if (!resume) {
    state.timerSeconds = TIMER_MAP[diff] || 20;
  }
  const total = TIMER_MAP[diff] || 20;
  updateTimerUI(state.timerSeconds, total);

  state.timerInterval = setInterval(() => {
    state.timerSeconds--;
    updateTimerUI(state.timerSeconds, total);
    if (state.timerSeconds <= 0) {
      clearInterval(state.timerInterval);
      timeOut();
    }
  }, 1000);
}

function updateTimerUI(current, total) {
  document.getElementById('timerNum').textContent = current;
  const ring = document.getElementById('timerRing');
  const offset = 113.1 * (1 - current / total);
  ring.style.strokeDashoffset = offset;
  const pct = current / total;
  ring.style.stroke =
    pct > 0.5 ? '#06b6d4' :
    pct > 0.25 ? '#f59e0b' : '#ef4444';
  document.getElementById('timerNum').style.color =
    pct > 0.5 ? '#e8e8f0' :
    pct > 0.25 ? '#f59e0b' : '#ef4444';
}

function timeOut() {
  const q = state.questions[state.currentIndex];
  const diff = q?.difficulty || state.difficulty;
  const maxTimer = TIMER_MAP[diff] || 20;
  disableOptions();
  highlightCorrect(q.correctAnswer);

  state.answerHistory.push({
    qNum: state.currentIndex + 1,
    correct: false,
    selected: -1,
    answer: q.correctAnswer,
    timedOut: true,
    timeTaken: maxTimer,
    maxTimer,
    pointsEarned: 0,
    runningScore: state.score,
    difficulty: diff
  });

  showExplanation(false, '⏱️ Time\'s up! ' + (q.explanation || ''), 'Time Out!');
  document.getElementById('nextBtn').classList.remove('hidden');
}

// ═══════════════════════════════════════════════════════════════════════════
// ANSWER SELECTION
// ═══════════════════════════════════════════════════════════════════════════
function selectAnswer(selected, correct, explanation) {
  clearInterval(state.timerInterval);
  disableOptions();

  const isCorrect = selected === correct;
  const diff = state.questions[state.currentIndex]?.difficulty || state.difficulty;
  const maxTimer = TIMER_MAP[diff] || 20;
  const timeTaken = Math.max(1, Math.min(maxTimer, Math.round((Date.now() - (state.qStartTime || Date.now())) / 1000)));

  document.getElementById(`opt-${selected}`).classList.add(isCorrect ? 'correct' : 'wrong');
  if (!isCorrect) highlightCorrect(correct);

  const ptsEarned = isCorrect ? (POINTS_MAP[diff] || 10) : 0;
  if (isCorrect) {
    state.score += ptsEarned;
    document.getElementById('currentScore').textContent = state.score;
    triggerCorrectEffect();
  }

  state.answerHistory.push({
    qNum: state.currentIndex + 1,
    correct: isCorrect,
    selected,
    answer: correct,
    timedOut: false,
    timeTaken,
    maxTimer,
    pointsEarned: ptsEarned,
    runningScore: state.score,
    difficulty: diff
  });

  showExplanation(isCorrect, explanation, isCorrect ? 'Correct! 🎉' : 'Wrong Answer');
  document.getElementById('nextBtn').classList.remove('hidden');
}

function triggerCorrectEffect() {
  const badge = document.getElementById('qNumBadge');
  badge.style.transform = 'scale(1.4)';
  badge.style.boxShadow = '0 0 24px rgba(16,185,129,0.6)';
  setTimeout(() => { badge.style.transform = ''; badge.style.boxShadow = ''; }, 400);
}

function highlightCorrect(idx) {
  document.getElementById(`opt-${idx}`)?.classList.add('correct');
}
function disableOptions() {
  document.querySelectorAll('.option-btn').forEach(b => b.disabled = true);
}

function showExplanation(correct, text, title = '') {
  const panel = document.getElementById('explanationPanel');
  panel.classList.remove('hidden');
  document.getElementById('expIcon').textContent  = correct ? '✅' : '❌';
  document.getElementById('expTitle').textContent = title || (correct ? 'Correct!' : 'Wrong Answer');
  document.getElementById('expTitle').style.color = correct ? 'var(--green)' : 'var(--red)';
  document.getElementById('explanationText').textContent = text || '';
  panel.style.borderColor = correct ? 'rgba(16,185,129,0.3)' : 'rgba(239,68,68,0.25)';
}

// ═══════════════════════════════════════════════════════════════════════════
// NEXT QUESTION
// ═══════════════════════════════════════════════════════════════════════════
function nextQuestion() {
  state.currentIndex++;
  if (state.currentIndex >= state.questions.length) {
    endGame();
  } else {
    renderQuestion();
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// END GAME
// ═══════════════════════════════════════════════════════════════════════════
let currentGraphView = 'timeline';
let performanceChartInstance = null;

async function endGame() {
  clearInterval(state.timerInterval);
  hideCategoryBg();
  const total    = state.questions.length;
  const correct  = state.answerHistory.filter(a => a.correct).length;
  const accuracy = total > 0 ? Math.round((correct / total) * 100) : 0;
  const timeTaken = Math.round((Date.now() - state.startTime) / 1000);

  // Compute advanced AI and graph performance metrics
  const history = state.answerHistory || [];
  const avgQTime = history.length > 0
    ? (history.reduce((sum, h) => sum + (h.timeTaken || 0), 0) / history.length).toFixed(1)
    : 0;

  const correctAnswers = history.filter(h => h.correct);
  const fastest = correctAnswers.length > 0
    ? Math.min(...correctAnswers.map(h => h.timeTaken))
    : (history.length > 0 ? Math.min(...history.map(h => h.timeTaken)) : 0);

  let currentStreak = 0, maxStreak = 0;
  history.forEach(h => {
    if (h.correct) {
      currentStreak++;
      if (currentStreak > maxStreak) maxStreak = currentStreak;
    } else {
      currentStreak = 0;
    }
  });

  const maxTimer = TIMER_MAP[state.difficulty] || 20;
  const efficiency = Math.max(0, Math.min(100, Math.round((1 - (avgQTime / maxTimer)) * 100)));

  const stats = {
    total,
    correct,
    accuracy,
    timeTaken,
    avgQTime,
    fastest,
    maxStreak,
    efficiency,
    maxTimer,
    category: state.category,
    difficulty: state.difficulty
  };
  state.lastStats = stats;

  showScreen('screen-result');

  // Trophy & title
  const trophy = accuracy >= 90 ? '🏆' : accuracy >= 70 ? '🥇' : accuracy >= 50 ? '🥈' : accuracy >= 30 ? '🥉' : '💡';
  document.getElementById('resultTrophy').textContent  = trophy;
  const titles = { 90:'Outstanding! 🔥', 70:'Great Work! 👍', 50:'Good Effort! 📚', 30:'Keep Practicing 💪', 0:'Never Give Up! 🚀' };
  const titleKey = [90,70,50,30,0].find(k => accuracy >= k);
  document.getElementById('resultTitle').textContent   = titles[titleKey];
  document.getElementById('resultSubtitle').textContent = `${state.category} · ${state.difficulty} · ${state.language.toUpperCase()}`;

  // Stats
  document.getElementById('finalScore').textContent    = state.score;
  document.getElementById('finalAccuracy').textContent = accuracy + '%';
  document.getElementById('finalTime').textContent     = timeTaken + 's';

  // Animate stat rings
  setTimeout(() => {
    const circ = 150.8;
    const scoreMax = total * 30;
    const scoreRatio = Math.min(state.score / scoreMax, 1);
    animRing('scoreRing', scoreRatio, circ);
    animRing('accuracyRing', accuracy / 100, circ);
  }, 300);

  // Save game to local history so previous scores and performance graphs can always be inspected
  const savedEntry = saveGameToHistory(stats);
  state.currentSessionEntry = savedEntry;
  populatePreviousAttemptsDropdown();
  hidePreviousScoreBanner();

  // ── Render AI Diagnostic & Hologram Animation ──
  renderAiDiagnostic(stats);

  // ── Render Performance Graph ──
  currentGraphView = 'timeline';
  renderPerformanceGraph('timeline', stats);

  // Summary card
  document.getElementById('resultCard').innerHTML = `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px 24px;font-size:0.9rem">
      <span style="color:var(--muted)">👤 Player</span>   <span style="font-weight:700">${escapeHtml(state.playerName)}</span>
      <span style="color:var(--muted)">📚 Topic</span>    <span style="font-weight:700">${escapeHtml(state.category)}</span>
      <span style="color:var(--muted)">🎯 Difficulty</span><span class="diff-pill ${state.difficulty}" style="width:fit-content">${state.difficulty}</span>
      <span style="color:var(--muted)">✅ Correct</span>  <span style="font-weight:700;color:var(--green)">${correct} / ${total}</span>
      <span style="color:var(--muted)">⭐ Score</span>    <span style="font-weight:900;color:var(--cyan);font-size:1.1rem">${state.score} pts</span>
      <span style="color:var(--muted)">⏱️ Time</span>     <span style="font-weight:700">${timeTaken}s</span>
    </div>`;

  // Answer review dots
  const review = document.getElementById('answerReview');
  review.innerHTML = state.answerHistory.map((a, i) => {
    const cls = a.timedOut ? 'timeout' : a.correct ? 'correct' : 'wrong';
    const sym = a.timedOut ? '⏱' : a.correct ? '✓' : '✗';
    return `<div class="ar-dot ${cls}" title="Q${i+1}: ${cls}">${sym}</div>`;
  }).join('');

  // Fireworks for high scores
  if (accuracy >= 70) triggerFireworks();

  // Save score
  try {
    await fetch('/api/scores', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        playerName: state.playerName, score: state.score,
        totalQuestions: total, difficulty: state.difficulty,
        category: state.category, language: state.language, timeTaken
      })
    });
  } catch {}
}

// ═══════════════════════════════════════════════════════════════════════════
// AI PERFORMANCE DIAGNOSTIC EVALUATION
// ═══════════════════════════════════════════════════════════════════════════
function generateAiEvaluation(accuracy, avgTime, bestStreak, diff, total) {
  let title = '';
  let feedback = '';
  let velocityLabel = '';
  let precisionLabel = `${accuracy}% Precision`;
  let streakLabel = `${bestStreak} / ${total} Qs`;
  let rankLabel = '';

  // Velocity factor
  if (avgTime < 3.5) {
    velocityLabel = `⚡ Hyper-Fast (${avgTime}s/Q)`;
  } else if (avgTime < 7) {
    velocityLabel = `🚀 Swift Pace (${avgTime}s/Q)`;
  } else if (avgTime < 14) {
    velocityLabel = `⏱️ Steady Focus (${avgTime}s/Q)`;
  } else {
    velocityLabel = `⏳ Deliberate (${avgTime}s/Q)`;
  }

  // Tier & Assessment
  if (accuracy >= 90) {
    title = 'Architect Tier · Elite Cognitive Precision 🔥';
    rankLabel = 'Grandmaster';
    feedback = `Exceptional synaptic performance! You mastered ${state.category} (${diff}) with ${accuracy}% accuracy and an average speed of ${avgTime}s per question. Your sustained peak streak of ${bestStreak} indicates deep conceptual fluency and production-ready algorithmic recall.`;
  } else if (accuracy >= 70) {
    title = 'Senior Developer Tier · Robust Technical Acumen 💎';
    rankLabel = 'Senior Specialist';
    feedback = `High-level engineering intuition detected! You achieved ${accuracy}% precision on ${state.category} questions. Your reasoning balance between speed and precision is strong. Target tricky edge cases to breach the 90% Grandmaster threshold.`;
  } else if (accuracy >= 50) {
    title = 'Practitioner Tier · Solid Core Competence ⚡';
    rankLabel = 'Proficient';
    feedback = `Solid technical foundation shown across ${state.category}. Core syntax is well-understood, though AI telemetry detected latency fluctuations on nested logic. Quick spaced-repetition drills will elevate your response velocity.`;
  } else {
    title = 'Apprentice Tier · Foundations In Development 📚';
    rankLabel = 'Rising Engineer';
    feedback = `Diagnostic baseline established. Analysis reveals areas for growth in ${state.category} fundamentals, but disciplined pacing was maintained. Review the answers below, examine the explanations, and retry to build synaptic muscle memory!`;
  }

  return { title, feedback, velocityLabel, precisionLabel, streakLabel, rankLabel };
}

function renderAiDiagnostic(stats) {
  const headingEl = document.getElementById('aiEvalHeading');
  const textEl = document.getElementById('aiEvalText');
  const velEl = document.getElementById('aiVelocityVal');
  const precEl = document.getElementById('aiPrecisionVal');
  const streakEl = document.getElementById('aiStreakVal');
  const rankEl = document.getElementById('aiRankVal');

  const { title, feedback, velocityLabel, precisionLabel, streakLabel, rankLabel } =
    generateAiEvaluation(stats.accuracy, stats.avgQTime, stats.maxStreak, stats.difficulty, stats.total);

  if (headingEl) headingEl.textContent = title;
  if (textEl) textEl.textContent = feedback;
  if (velEl) velEl.textContent = velocityLabel;
  if (precEl) precEl.textContent = precisionLabel;
  if (streakEl) streakEl.textContent = streakLabel;
  if (rankEl) rankEl.textContent = rankLabel;
}

// ═══════════════════════════════════════════════════════════════════════════
// PERFORMANCE GRAPH CONTROLLER
// ═══════════════════════════════════════════════════════════════════════════
function switchGraphView(view) {
  currentGraphView = view;
  document.querySelectorAll('.graph-tab-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.view === view);
  });
  renderPerformanceGraph(view, state.lastStats);
}

function renderPerformanceGraph(view = currentGraphView, stats = state.lastStats) {
  if (!stats) return;
  state.lastStats = stats;

  // Update KPI metric values
  const avgEl = document.getElementById('kpiAvgTime');
  const fastEl = document.getElementById('kpiFastestTime');
  const streakEl = document.getElementById('kpiBestStreak');
  const effEl = document.getElementById('kpiEfficiency');

  if (avgEl) avgEl.textContent = `${stats.avgQTime}s`;
  if (fastEl) fastEl.textContent = `${stats.fastest}s`;
  if (streakEl) streakEl.textContent = `${stats.maxStreak} Qs`;
  if (effEl) effEl.textContent = `${stats.efficiency}%`;

  const canvas = document.getElementById('performanceChart');
  if (!canvas) return;

  const history = state.answerHistory || [];
  const labels = history.map((h, i) => `Q${i + 1}`);

  // Update dynamic custom legend
  const legend = document.getElementById('chartCustomLegend');
  if (legend) {
    if (view === 'timeline') {
      const correctCount = history.filter(h => h.correct).length;
      const wrongCount = history.filter(h => !h.correct && !h.timedOut).length;
      const timeCount = history.filter(h => h.timedOut).length;
      legend.innerHTML = `
        <div class="legend-item"><span class="legend-dot c-green"></span><span>Correct (${correctCount})</span></div>
        <div class="legend-item"><span class="legend-dot c-red"></span><span>Incorrect (${wrongCount})</span></div>
        <div class="legend-item"><span class="legend-dot c-yellow"></span><span>Timeout (${timeCount})</span></div>
        <div class="legend-item"><span class="legend-dot c-cyan"></span><span>Score Progression</span></div>
      `;
    } else if (view === 'radar') {
      legend.innerHTML = `
        <div class="legend-item"><span class="legend-dot c-cyan"></span><span>Your Skill Matrix</span></div>
        <div class="legend-item"><span class="legend-dot c-violet"></span><span>Benchmark Target</span></div>
      `;
    } else {
      legend.innerHTML = `
        <div class="legend-item"><span class="legend-dot c-green"></span><span>Your Response Time</span></div>
        <div class="legend-item"><span class="legend-dot c-yellow"></span><span>Allowed Limit (${stats.maxTimer}s)</span></div>
      `;
    }
  }

  // Use Chart.js if available, otherwise seamless HTML5 Canvas fallback
  if (typeof Chart !== 'undefined') {
    renderChartJsGraph(canvas, view, stats, history, labels);
  } else {
    renderCanvasFallback(canvas, view, stats, history, labels);
  }
}

function renderChartJsGraph(canvas, view, stats, history, labels) {
  if (performanceChartInstance) {
    performanceChartInstance.destroy();
    performanceChartInstance = null;
  }

  const ctx = canvas.getContext('2d');

  if (view === 'timeline') {
    const times = history.map(h => h.timeTaken || 0);
    const scores = history.map(h => h.runningScore || 0);
    const barColors = history.map(h =>
      h.timedOut ? 'rgba(245, 158, 11, 0.85)' :
      h.correct  ? 'rgba(16, 185, 129, 0.85)' :
                   'rgba(239, 68, 68, 0.85)'
    );

    performanceChartInstance = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [
          {
            type: 'line',
            label: 'Cumulative Score',
            data: scores,
            borderColor: '#06b6d4',
            backgroundColor: 'rgba(6, 182, 212, 0.12)',
            fill: true,
            tension: 0.35,
            borderWidth: 3,
            pointBackgroundColor: '#67e8f9',
            pointBorderColor: '#0891b2',
            pointRadius: 5,
            pointHoverRadius: 7,
            yAxisID: 'yScore'
          },
          {
            type: 'bar',
            label: 'Response Time (s)',
            data: times,
            backgroundColor: barColors,
            borderRadius: 6,
            borderSkipped: false,
            yAxisID: 'yTime'
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: { duration: 900, easing: 'easeOutQuart' },
        interaction: { mode: 'index', intersect: false },
        plugins: {
          legend: { display: false },
          tooltip: {
            backgroundColor: 'rgba(10, 10, 28, 0.95)',
            titleColor: '#e2e8f0',
            bodyColor: '#94a3b8',
            borderColor: 'rgba(255, 255, 255, 0.15)',
            borderWidth: 1,
            padding: 12,
            displayColors: true,
            callbacks: {
              afterLabel: function(ctx) {
                if (ctx.datasetIndex === 1) {
                  const h = history[ctx.dataIndex];
                  return h ? (h.timedOut ? '⏱️ Timed Out' : (h.correct ? '✅ Correct (+points)' : '❌ Incorrect')) : '';
                }
              }
            }
          }
        },
        scales: {
          x: {
            grid: { color: 'rgba(255, 255, 255, 0.05)' },
            ticks: { color: '#94a3b8', font: { family: 'Outfit', weight: '600' } }
          },
          yTime: {
            type: 'linear',
            position: 'left',
            grid: { color: 'rgba(255, 255, 255, 0.05)' },
            ticks: {
              color: '#10b981',
              callback: v => v + 's'
            },
            title: {
              display: true,
              text: 'Response Time',
              color: '#10b981',
              font: { family: 'Outfit', size: 11, weight: '700' }
            }
          },
          yScore: {
            type: 'linear',
            position: 'right',
            grid: { drawOnChartArea: false },
            ticks: {
              color: '#06b6d4',
              callback: v => v + ' pts'
            },
            title: {
              display: true,
              text: 'Score Curve',
              color: '#06b6d4',
              font: { family: 'Outfit', size: 11, weight: '700' }
            }
          }
        }
      }
    });

  } else if (view === 'radar') {
    const accuracy = stats.accuracy;
    const speedRating = Math.max(10, Math.min(100, Math.round(100 - (stats.avgQTime / stats.maxTimer * 80))));
    const streakRating = Math.min(100, Math.round((stats.maxStreak / Math.max(1, stats.total)) * 100));
    const diffBonus = stats.difficulty === 'hard' ? 95 : stats.difficulty === 'medium' ? 75 : 55;
    const timeRetention = Math.round(((stats.total - history.filter(h => h.timedOut).length) / Math.max(1, stats.total)) * 100);

    performanceChartInstance = new Chart(ctx, {
      type: 'radar',
      data: {
        labels: ['Precision', 'Speed Factor', 'Streak Agility', 'Topic Depth', 'Focus & Time'],
        datasets: [
          {
            label: 'Your Metrics',
            data: [accuracy, speedRating, streakRating, diffBonus, timeRetention],
            backgroundColor: 'rgba(6, 182, 212, 0.25)',
            borderColor: '#06b6d4',
            borderWidth: 2.5,
            pointBackgroundColor: '#67e8f9',
            pointBorderColor: '#0891b2',
            pointRadius: 4
          },
          {
            label: 'Benchmark',
            data: [75, 70, 60, 70, 80],
            backgroundColor: 'rgba(124, 58, 237, 0.1)',
            borderColor: 'rgba(124, 58, 237, 0.5)',
            borderDash: [5, 5],
            borderWidth: 1.5,
            pointRadius: 2
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: { duration: 900, easing: 'easeOutQuart' },
        plugins: {
          legend: { display: false }
        },
        scales: {
          r: {
            min: 0,
            max: 100,
            grid: { color: 'rgba(255, 255, 255, 0.08)' },
            angleLines: { color: 'rgba(255, 255, 255, 0.08)' },
            pointLabels: {
              color: '#e2e8f0',
              font: { family: 'Outfit', size: 11, weight: '700' }
            },
            ticks: { display: false }
          }
        }
      }
    });

  } else if (view === 'speed') {
    const times = history.map(h => h.timeTaken || 0);
    const limits = history.map(h => h.maxTimer || stats.maxTimer || 20);

    performanceChartInstance = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: labels,
        datasets: [
          {
            label: 'Your Time',
            data: times,
            backgroundColor: history.map(h => h.timedOut ? 'rgba(245, 158, 11, 0.85)' : (h.correct ? 'rgba(16, 185, 129, 0.85)' : 'rgba(239, 68, 68, 0.85)')),
            borderRadius: 6
          },
          {
            label: 'Allowed Limit',
            data: limits,
            backgroundColor: 'rgba(255, 255, 255, 0.08)',
            borderColor: 'rgba(245, 158, 11, 0.35)',
            borderWidth: 1,
            borderRadius: 6
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: { duration: 900, easing: 'easeOutQuart' },
        plugins: {
          legend: { display: false }
        },
        scales: {
          x: {
            grid: { color: 'rgba(255, 255, 255, 0.05)' },
            ticks: { color: '#94a3b8' }
          },
          y: {
            grid: { color: 'rgba(255, 255, 255, 0.05)' },
            ticks: { color: '#94a3b8', callback: v => v + 's' }
          }
        }
      }
    });
  }
}

// ── Native HTML5 Canvas Fallback Renderer (Offline-ready) ──
function renderCanvasFallback(canvas, view, stats, history, labels) {
  const container = canvas.parentElement;
  const W = container.clientWidth || 600;
  const H = 260;
  const dpr = window.devicePixelRatio || 1;
  canvas.width = W * dpr;
  canvas.height = H * dpr;
  canvas.style.width = W + 'px';
  canvas.style.height = H + 'px';

  const ctx = canvas.getContext('2d');
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, W, H);

  const padLeft = 45, padRight = 45, padTop = 25, padBottom = 35;
  const plotW = W - padLeft - padRight;
  const plotH = H - padTop - padBottom;

  if (view === 'timeline') {
    // Grid lines
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.06)';
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const y = padTop + (plotH / 4) * i;
      ctx.beginPath();
      ctx.moveTo(padLeft, y);
      ctx.lineTo(W - padRight, y);
      ctx.stroke();

      const timeVal = Math.round(stats.maxTimer * (1 - i / 4));
      ctx.fillStyle = '#64748b';
      ctx.font = '10px monospace';
      ctx.textAlign = 'right';
      ctx.fillText(timeVal + 's', padLeft - 8, y + 3);
    }

    const n = history.length;
    if (n === 0) return;
    const colW = plotW / n;
    const barW = Math.max(8, colW * 0.45);

    // Bars
    history.forEach((h, i) => {
      const x = padLeft + colW * i + (colW - barW) / 2;
      const hRatio = Math.min(1, (h.timeTaken || 1) / stats.maxTimer);
      const bH = plotH * hRatio;
      const y = padTop + plotH - bH;

      ctx.fillStyle = h.timedOut ? '#f59e0b' : (h.correct ? '#10b981' : '#ef4444');
      ctx.beginPath();
      if (ctx.roundRect) ctx.roundRect(x, y, barW, bH, [4, 4, 0, 0]);
      else ctx.rect(x, y, barW, bH);
      ctx.fill();

      // Q label
      ctx.fillStyle = '#94a3b8';
      ctx.font = '11px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(`Q${i + 1}`, x + barW / 2, H - 12);
    });

    // Score curve
    const maxScore = Math.max(1, n * 30);
    ctx.beginPath();
    ctx.strokeStyle = '#06b6d4';
    ctx.lineWidth = 2.5;

    history.forEach((h, i) => {
      const x = padLeft + colW * i + colW / 2;
      const scoreRatio = Math.min(1, (h.runningScore || 0) / maxScore);
      const y = padTop + plotH - (plotH * scoreRatio);
      if (i === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.stroke();

    // Data points
    history.forEach((h, i) => {
      const x = padLeft + colW * i + colW / 2;
      const scoreRatio = Math.min(1, (h.runningScore || 0) / maxScore);
      const y = padTop + plotH - (plotH * scoreRatio);
      ctx.beginPath();
      ctx.arc(x, y, 4, 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff';
      ctx.fill();
      ctx.strokeStyle = '#06b6d4';
      ctx.lineWidth = 2;
      ctx.stroke();
    });

  } else if (view === 'radar') {
    const cx = W / 2;
    const cy = H / 2;
    const r = Math.min(plotW, plotH) / 2.2;
    const metrics = ['Accuracy', 'Speed', 'Streak', 'Topic', 'Time'];
    const values = [
      stats.accuracy,
      Math.max(10, Math.min(100, Math.round(100 - (stats.avgQTime / stats.maxTimer * 80)))),
      Math.min(100, Math.round((stats.maxStreak / Math.max(1, stats.total)) * 100)),
      stats.difficulty === 'hard' ? 95 : stats.difficulty === 'medium' ? 75 : 55,
      Math.round(((stats.total - history.filter(h => h.timedOut).length) / Math.max(1, stats.total)) * 100)
    ];

    for (let level = 1; level <= 4; level++) {
      const lr = (r / 4) * level;
      ctx.beginPath();
      for (let i = 0; i < 5; i++) {
        const ang = (Math.PI * 2 / 5) * i - Math.PI / 2;
        const x = cx + Math.cos(ang) * lr;
        const y = cy + Math.sin(ang) * lr;
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.closePath();
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
      ctx.stroke();
    }

    for (let i = 0; i < 5; i++) {
      const ang = (Math.PI * 2 / 5) * i - Math.PI / 2;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(cx + Math.cos(ang) * r, cy + Math.sin(ang) * r);
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
      ctx.stroke();

      const lx = cx + Math.cos(ang) * (r + 18);
      const ly = cy + Math.sin(ang) * (r + 18);
      ctx.fillStyle = '#cbd5e1';
      ctx.font = '11px sans-serif';
      ctx.textAlign = 'center';
      ctx.fillText(metrics[i], lx, ly + 4);
    }

    ctx.beginPath();
    for (let i = 0; i < 5; i++) {
      const ang = (Math.PI * 2 / 5) * i - Math.PI / 2;
      const vr = (values[i] / 100) * r;
      const x = cx + Math.cos(ang) * vr;
      const y = cy + Math.sin(ang) * vr;
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.fillStyle = 'rgba(6, 182, 212, 0.25)';
    ctx.fill();
    ctx.strokeStyle = '#06b6d4';
    ctx.lineWidth = 2.5;
    ctx.stroke();

  } else if (view === 'speed') {
    const n = history.length;
    const colW = plotW / Math.max(1, n);
    const barW = Math.max(6, colW * 0.35);

    history.forEach((h, i) => {
      const cx = padLeft + colW * i + colW / 2;
      const userH = plotH * Math.min(1, (h.timeTaken || 0) / stats.maxTimer);
      const limH = plotH;

      ctx.fillStyle = 'rgba(255, 255, 255, 0.08)';
      ctx.fillRect(cx - barW, padTop + plotH - limH, barW, limH);

      ctx.fillStyle = h.timedOut ? '#f59e0b' : (h.correct ? '#10b981' : '#ef4444');
      ctx.fillRect(cx, padTop + plotH - userH, barW, userH);

      ctx.fillStyle = '#94a3b8';
      ctx.font = '10px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(`Q${i + 1}`, cx, H - 12);
    });
  }
}

// Window resize handler for chart
window.addEventListener('resize', () => {
  if (state.lastStats && document.getElementById('screen-result')?.classList.contains('active')) {
    renderPerformanceGraph(currentGraphView, state.lastStats);
  }
});

function animRing(id, ratio, circ) {
  const el = document.getElementById(id);
  if (el) el.style.strokeDashoffset = circ * (1 - ratio);
}

// ─── Fireworks ───────────────────────────────────────────────────────────────
function triggerFireworks() {
  const container = document.getElementById('resultFireworks');
  if (!container) return;
  const colors = ['#7c3aed','#06b6d4','#10b981','#f59e0b','#ec4899','#6366f1'];
  for (let i = 0; i < 40; i++) {
    const p = document.createElement('div');
    const color = colors[Math.floor(Math.random() * colors.length)];
    const x = Math.random() * 100;
    const y = Math.random() * 100;
    const size = Math.random() * 6 + 3;
    p.style.cssText = `
      position:absolute;left:${x}%;top:${y}%;
      width:${size}px;height:${size}px;border-radius:50%;
      background:${color};pointer-events:none;
      animation:fw ${0.8 + Math.random() * 1.2}s ease-out ${Math.random() * 0.8}s forwards;`;
    container.appendChild(p);
  }
  // Add firework keyframe
  if (!document.getElementById('fwStyle')) {
    const s = document.createElement('style');
    s.id = 'fwStyle';
    s.textContent = `@keyframes fw{0%{transform:scale(0) translateY(0);opacity:1}100%{transform:scale(1) translateY(-60px);opacity:0}}`;
    document.head.appendChild(s);
  }
  setTimeout(() => container.innerHTML = '', 3000);
}

// ═══════════════════════════════════════════════════════════════════════════
// PREVIOUS SCORE & PERFORMANCE HISTORY SYSTEM
// ═══════════════════════════════════════════════════════════════════════════
let currentHistoryTab = 'score';
let historyChartInstance = null;

function getLocalHistory() {
  try {
    const raw = localStorage.getItem('techquiz_history');
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveGameToHistory(stats) {
  try {
    const historyList = getLocalHistory();
    const entry = {
      id: 'session_' + Date.now(),
      timestamp: Date.now(),
      dateStr: new Date().toLocaleDateString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }),
      playerName: state.playerName,
      category: state.category,
      difficulty: state.difficulty,
      language: state.language,
      score: state.score,
      total: stats.total,
      correct: stats.correct,
      accuracy: stats.accuracy,
      timeTaken: stats.timeTaken,
      avgQTime: stats.avgQTime,
      fastest: stats.fastest,
      maxStreak: stats.maxStreak,
      efficiency: stats.efficiency,
      maxTimer: stats.maxTimer,
      answerHistory: JSON.parse(JSON.stringify(state.answerHistory || []))
    };
    historyList.unshift(entry);
    if (historyList.length > 50) historyList.pop();
    localStorage.setItem('techquiz_history', JSON.stringify(historyList));
    return entry;
  } catch (e) {
    console.warn('Could not save to localStorage', e);
    return null;
  }
}

function populatePreviousAttemptsDropdown() {
  const sel = document.getElementById('prevAttemptsSelect');
  if (!sel) return;

  const historyList = getLocalHistory();
  sel.innerHTML = '<option value="current">Current Quiz (Latest)</option>';

  historyList.forEach((item, idx) => {
    const opt = document.createElement('option');
    opt.value = item.id;
    opt.textContent = `#${historyList.length - idx}: ${item.category} (${item.difficulty}) · ${item.score} pts [${item.dateStr}]`;
    sel.appendChild(opt);
  });
}

function onSelectPreviousAttempt(attemptId) {
  if (attemptId === 'current') {
    restoreCurrentSession();
  } else {
    viewPreviousAttempt(attemptId);
  }
}

function viewPreviousAttempt(attemptId) {
  const historyList = getLocalHistory();
  const entry = historyList.find(item => item.id === attemptId);
  if (!entry) return;

  // Set answerHistory and lastStats from entry
  state.lastStats = {
    total: entry.total,
    correct: entry.correct,
    accuracy: entry.accuracy,
    timeTaken: entry.timeTaken,
    avgQTime: entry.avgQTime,
    fastest: entry.fastest,
    maxStreak: entry.maxStreak,
    efficiency: entry.efficiency,
    maxTimer: entry.maxTimer,
    category: entry.category,
    difficulty: entry.difficulty
  };
  state.answerHistory = entry.answerHistory || [];

  // Show previous score banner
  const banner = document.getElementById('previousScoreBanner');
  const bannerText = document.getElementById('prevScoreBannerText');
  if (banner && bannerText) {
    banner.classList.remove('hidden');
    bannerText.innerHTML = `Viewing Previous Game: <strong>${escapeHtml(entry.category)} (${entry.difficulty})</strong> · Score: <strong>${entry.score} pts</strong> · ${entry.dateStr}`;
  }

  // Update dropdown selection if present
  const sel = document.getElementById('prevAttemptsSelect');
  if (sel) sel.value = attemptId;

  // Update Result Stats
  document.getElementById('finalScore').textContent = entry.score;
  document.getElementById('finalAccuracy').textContent = entry.accuracy + '%';
  document.getElementById('finalTime').textContent = entry.timeTaken + 's';

  const trophy = entry.accuracy >= 90 ? '🏆' : entry.accuracy >= 70 ? '🥇' : entry.accuracy >= 50 ? '🥈' : entry.accuracy >= 30 ? '🥉' : '💡';
  document.getElementById('resultTrophy').textContent = trophy;
  const titles = { 90:'Outstanding! 🔥', 70:'Great Work! 👍', 50:'Good Effort! 📚', 30:'Keep Practicing 💪', 0:'Never Give Up! 🚀' };
  const titleKey = [90,70,50,30,0].find(k => entry.accuracy >= k);
  document.getElementById('resultTitle').textContent = titles[titleKey];
  document.getElementById('resultSubtitle').textContent = `${entry.category} · ${entry.difficulty} · ${entry.language?.toUpperCase() || 'EN'}`;

  // Update Result Card
  document.getElementById('resultCard').innerHTML = `
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px 24px;font-size:0.9rem">
      <span style="color:var(--muted)">👤 Player</span>   <span style="font-weight:700">${escapeHtml(entry.playerName || 'Player')}</span>
      <span style="color:var(--muted)">📚 Topic</span>    <span style="font-weight:700">${escapeHtml(entry.category)}</span>
      <span style="color:var(--muted)">🎯 Difficulty</span><span class="diff-pill ${entry.difficulty}" style="width:fit-content">${entry.difficulty}</span>
      <span style="color:var(--muted)">✅ Correct</span>  <span style="font-weight:700;color:var(--green)">${entry.correct} / ${entry.total}</span>
      <span style="color:var(--muted)">⭐ Score</span>    <span style="font-weight:900;color:var(--cyan);font-size:1.1rem">${entry.score} pts</span>
      <span style="color:var(--muted)">⏱️ Time</span>     <span style="font-weight:700">${entry.timeTaken}s</span>
    </div>`;

  // Answer review dots
  const review = document.getElementById('answerReview');
  if (review) {
    review.innerHTML = state.answerHistory.map((a, i) => {
      const cls = a.timedOut ? 'timeout' : a.correct ? 'correct' : 'wrong';
      const sym = a.timedOut ? '⏱' : a.correct ? '✓' : '✗';
      return `<div class="ar-dot ${cls}" title="Q${i+1}: ${cls}">${sym}</div>`;
    }).join('');
  }

  // Render AI and performance graph for this attempt
  renderAiDiagnostic(state.lastStats);
  renderPerformanceGraph(currentGraphView, state.lastStats);

  // Switch to result screen
  showScreen('screen-result');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function restoreCurrentSession() {
  hidePreviousScoreBanner();
  const sel = document.getElementById('prevAttemptsSelect');
  if (sel) sel.value = 'current';

  if (state.currentSessionEntry) {
    viewPreviousAttempt(state.currentSessionEntry.id);
    hidePreviousScoreBanner();
  }
}

function hidePreviousScoreBanner() {
  const banner = document.getElementById('previousScoreBanner');
  if (banner) banner.classList.add('hidden');
}

function openPerformanceHistory() {
  const activeScreen = document.querySelector('.screen.active');
  state.historyBackScreen = activeScreen ? activeScreen.id : 'screen-home';

  showScreen('screen-history');
  renderPerformanceHistoryScreen();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function goBackFromHistory() {
  showScreen(state.historyBackScreen || 'screen-home');
}

function switchHistoryGraphTab(tab) {
  currentHistoryTab = tab;
  document.getElementById('histTabScore')?.classList.toggle('active', tab === 'score');
  document.getElementById('histTabAccuracy')?.classList.toggle('active', tab === 'accuracy');
  renderHistoryProgressionChart(tab);
}

function renderPerformanceHistoryScreen() {
  const historyList = getLocalHistory();
  const total = historyList.length;

  let bestScore = 0;
  let sumAccuracy = 0;
  let sumAvgSpeed = 0;

  historyList.forEach(item => {
    if ((item.score || 0) > bestScore) bestScore = item.score;
    sumAccuracy += (item.accuracy || 0);
    sumAvgSpeed += parseFloat(item.avgQTime || 0);
  });

  const avgAccuracy = total > 0 ? Math.round(sumAccuracy / total) : 0;
  const avgVelocity = total > 0 ? (sumAvgSpeed / total).toFixed(1) : '0.0';

  const totEl = document.getElementById('histTotalGames');
  const bestEl = document.getElementById('histBestScore');
  const accEl = document.getElementById('histAvgAccuracy');
  const spdEl = document.getElementById('histAvgSpeed');
  const countBadge = document.getElementById('historyCountBadge');

  if (totEl) totEl.textContent = total;
  if (bestEl) bestEl.textContent = `${bestScore} pts`;
  if (accEl) accEl.textContent = `${avgAccuracy}%`;
  if (spdEl) spdEl.textContent = `${avgVelocity}s`;
  if (countBadge) countBadge.textContent = `${total} quiz session${total === 1 ? '' : 's'} recorded`;

  renderHistoryProgressionChart(currentHistoryTab, historyList);
  renderHistoryListItems(historyList);
}

function renderHistoryProgressionChart(tab = currentHistoryTab, historyList = getLocalHistory()) {
  const canvas = document.getElementById('historyProgressionChart');
  if (!canvas) return;

  const chronological = [...historyList].reverse();
  const labels = chronological.map((item, idx) => `Quiz #${idx + 1}`);

  const legend = document.getElementById('historyChartLegend');
  if (legend) {
    if (tab === 'score') {
      legend.innerHTML = `
        <div class="legend-item"><span class="legend-dot c-cyan"></span><span>Score Progression</span></div>
        <div class="legend-item"><span class="legend-dot c-violet"></span><span>Average Benchmark</span></div>
      `;
    } else {
      legend.innerHTML = `
        <div class="legend-item"><span class="legend-dot c-green"></span><span>Accuracy (%)</span></div>
        <div class="legend-item"><span class="legend-dot c-yellow"></span><span>Avg Response Speed (s)</span></div>
      `;
    }
  }

  if (chronological.length === 0) {
    const ctx = canvas.getContext('2d');
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#64748b';
    ctx.font = '14px Outfit';
    ctx.textAlign = 'center';
    ctx.fillText('Play quizzes to see your multi-game performance progression graph!', canvas.width / 2, canvas.height / 2);
    return;
  }

  if (typeof Chart !== 'undefined') {
    if (historyChartInstance) {
      historyChartInstance.destroy();
      historyChartInstance = null;
    }
    const ctx = canvas.getContext('2d');

    if (tab === 'score') {
      const scores = chronological.map(h => h.score || 0);
      const avgScore = Math.round(scores.reduce((a, b) => a + b, 0) / scores.length);

      historyChartInstance = new Chart(ctx, {
        type: 'line',
        data: {
          labels: labels,
          datasets: [
            {
              label: 'Score',
              data: scores,
              borderColor: '#06b6d4',
              backgroundColor: 'rgba(6, 182, 212, 0.15)',
              fill: true,
              tension: 0.35,
              borderWidth: 3,
              pointBackgroundColor: '#67e8f9',
              pointBorderColor: '#0891b2',
              pointRadius: 5,
              pointHoverRadius: 8
            },
            {
              label: 'Avg Score',
              data: chronological.map(() => avgScore),
              borderColor: 'rgba(124, 58, 237, 0.6)',
              borderDash: [5, 5],
              borderWidth: 1.5,
              pointRadius: 0
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          animation: { duration: 800 },
          plugins: {
            legend: { display: false },
            tooltip: {
              backgroundColor: 'rgba(10, 10, 28, 0.95)',
              titleColor: '#e2e8f0',
              bodyColor: '#94a3b8',
              borderColor: 'rgba(255, 255, 255, 0.15)',
              borderWidth: 1,
              callbacks: {
                afterLabel: function(ctx) {
                  const item = chronological[ctx.dataIndex];
                  return item ? `${item.category} (${item.difficulty}) · ${item.accuracy}% Acc` : '';
                }
              }
            }
          },
          scales: {
            x: {
              grid: { color: 'rgba(255, 255, 255, 0.05)' },
              ticks: { color: '#94a3b8' }
            },
            y: {
              grid: { color: 'rgba(255, 255, 255, 0.05)' },
              ticks: { color: '#06b6d4', callback: v => v + ' pts' }
            }
          }
        }
      });
    } else {
      const accuracies = chronological.map(h => h.accuracy || 0);
      const speeds = chronological.map(h => parseFloat(h.avgQTime || 0));

      historyChartInstance = new Chart(ctx, {
        type: 'line',
        data: {
          labels: labels,
          datasets: [
            {
              label: 'Accuracy (%)',
              data: accuracies,
              borderColor: '#10b981',
              backgroundColor: 'rgba(16, 185, 129, 0.12)',
              fill: true,
              tension: 0.3,
              borderWidth: 2.5,
              pointBackgroundColor: '#34d399',
              pointRadius: 4,
              yAxisID: 'yAcc'
            },
            {
              label: 'Avg Speed (s)',
              data: speeds,
              borderColor: '#f59e0b',
              backgroundColor: 'transparent',
              tension: 0.3,
              borderWidth: 2,
              pointBackgroundColor: '#fbbf24',
              pointRadius: 4,
              yAxisID: 'ySpeed'
            }
          ]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: { legend: { display: false } },
          scales: {
            x: {
              grid: { color: 'rgba(255, 255, 255, 0.05)' },
              ticks: { color: '#94a3b8' }
            },
            yAcc: {
              type: 'linear',
              position: 'left',
              min: 0,
              max: 100,
              grid: { color: 'rgba(255, 255, 255, 0.05)' },
              ticks: { color: '#10b981', callback: v => v + '%' }
            },
            ySpeed: {
              type: 'linear',
              position: 'right',
              grid: { drawOnChartArea: false },
              ticks: { color: '#f59e0b', callback: v => v + 's' }
            }
          }
        }
      });
    }
  } else {
    renderHistoryCanvasFallback(canvas, tab, chronological);
  }
}

function renderHistoryCanvasFallback(canvas, tab, chronological) {
  const container = canvas.parentElement;
  const W = container.clientWidth || 600;
  const H = 240;
  const dpr = window.devicePixelRatio || 1;
  canvas.width = W * dpr;
  canvas.height = H * dpr;
  canvas.style.width = W + 'px';
  canvas.style.height = H + 'px';

  const ctx = canvas.getContext('2d');
  ctx.scale(dpr, dpr);
  ctx.clearRect(0, 0, W, H);

  const padLeft = 45, padRight = 30, padTop = 20, padBottom = 30;
  const plotW = W - padLeft - padRight;
  const plotH = H - padTop - padBottom;
  const n = chronological.length;

  if (n === 0) return;

  ctx.strokeStyle = 'rgba(255, 255, 255, 0.06)';
  ctx.lineWidth = 1;
  for (let i = 0; i <= 4; i++) {
    const y = padTop + (plotH / 4) * i;
    ctx.beginPath();
    ctx.moveTo(padLeft, y);
    ctx.lineTo(W - padRight, y);
    ctx.stroke();
  }

  const colW = plotW / Math.max(1, n - 1 || 1);

  if (tab === 'score') {
    const maxScore = Math.max(...chronological.map(h => h.score || 0), 100);
    ctx.beginPath();
    ctx.strokeStyle = '#06b6d4';
    ctx.lineWidth = 3;

    chronological.forEach((h, i) => {
      const x = padLeft + (n === 1 ? plotW / 2 : colW * i);
      const y = padTop + plotH - (plotH * ((h.score || 0) / maxScore));
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    });
    ctx.stroke();

    chronological.forEach((h, i) => {
      const x = padLeft + (n === 1 ? plotW / 2 : colW * i);
      const y = padTop + plotH - (plotH * ((h.score || 0) / maxScore));
      ctx.beginPath();
      ctx.arc(x, y, 4, 0, Math.PI * 2);
      ctx.fillStyle = '#ffffff';
      ctx.fill();
      ctx.strokeStyle = '#06b6d4';
      ctx.lineWidth = 2;
      ctx.stroke();

      ctx.fillStyle = '#94a3b8';
      ctx.font = '10px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(`Qz${i + 1}`, x, H - 10);
    });
  } else {
    ctx.beginPath();
    ctx.strokeStyle = '#10b981';
    ctx.lineWidth = 2.5;
    chronological.forEach((h, i) => {
      const x = padLeft + (n === 1 ? plotW / 2 : colW * i);
      const y = padTop + plotH - (plotH * ((h.accuracy || 0) / 100));
      if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
    });
    ctx.stroke();

    chronological.forEach((h, i) => {
      const x = padLeft + (n === 1 ? plotW / 2 : colW * i);
      const y = padTop + plotH - (plotH * ((h.accuracy || 0) / 100));
      ctx.beginPath();
      ctx.arc(x, y, 4, 0, Math.PI * 2);
      ctx.fillStyle = '#10b981';
      ctx.fill();

      ctx.fillStyle = '#94a3b8';
      ctx.font = '10px monospace';
      ctx.textAlign = 'center';
      ctx.fillText(`Qz${i + 1}`, x, H - 10);
    });
  }
}

function renderHistoryListItems(historyList) {
  const listEl = document.getElementById('historyItemsList');
  if (!listEl) return;

  if (historyList.length === 0) {
    listEl.innerHTML = `
      <div class="history-empty-card">
        <div class="history-empty-icon">📊</div>
        <p><strong>No quiz history recorded yet.</strong></p>
        <p style="margin-top:6px;font-size:0.84rem">Start a challenge to generate your first performance graph and AI diagnostic report!</p>
      </div>`;
    return;
  }

  listEl.innerHTML = historyList.map((item, idx) => {
    const cfg = CAT_CONFIG[item.category] || {};
    const icon = cfg.icon || '📚';
    const num = historyList.length - idx;

    return `
      <div class="history-item-card">
        <div class="hic-left">
          <div class="hic-icon-box">${icon}</div>
          <div class="hic-meta">
            <div class="hic-title">Attempt #${num} · ${escapeHtml(item.category)}</div>
            <div class="hic-sub">
              <span class="diff-pill ${item.difficulty}" style="padding:2px 7px;font-size:0.65rem">${item.difficulty}</span>
              <span>${item.dateStr}</span>
            </div>
          </div>
        </div>

        <div class="hic-stats-row">
          <div class="hic-stat">
            <span class="hic-stat-val" style="color:var(--cyan)">${item.score} pts</span>
            <span class="hic-stat-key">Score</span>
          </div>
          <div class="hic-stat">
            <span class="hic-stat-val" style="color:var(--green)">${item.accuracy}%</span>
            <span class="hic-stat-key">Accuracy</span>
          </div>
          <div class="hic-stat">
            <span class="hic-stat-val" style="color:#f59e0b">${item.avgQTime || '-'}s</span>
            <span class="hic-stat-key">Speed/Q</span>
          </div>
        </div>

        <button class="hic-btn-action" onclick="viewPreviousAttempt('${item.id}')">
          <span>📊 View Performance Graph</span>
        </button>
      </div>`;
  }).join('');
}

function confirmClearHistory() {
  if (confirm('Are you sure you want to clear your local performance history?')) {
    localStorage.removeItem('techquiz_history');
    renderPerformanceHistoryScreen();
    populatePreviousAttemptsDropdown();
  }
}

// Populate dropdown on initial script evaluation
populatePreviousAttemptsDropdown();

// ═══════════════════════════════════════════════════════════════════════════
// LEADERBOARD
// ═══════════════════════════════════════════════════════════════════════════
async function loadLeaderboard() {
  const list = document.getElementById('lbList');
  list.innerHTML = '<div class="lb-loading"><div class="lb-load-spinner"></div>Loading scores...</div>';
  try {
    const res  = await fetch('/api/scores/leaderboard');
    const data = await res.json();
    if (!data.success || data.scores.length === 0) {
      list.innerHTML = '<div class="lb-loading">No scores yet. Be the first! 🚀</div>';
      return;
    }
    list.innerHTML = data.scores.map((s, i) => {
      const rankCls   = i === 0 ? 'gold' : i === 1 ? 'silver' : i === 2 ? 'bronze' : '';
      const rankLabel = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `#${i + 1}`;
      const cfg       = CAT_CONFIG[s.category] || {};
      return `
      <div class="lb-item" style="animation-delay:${i * 0.06}s">
        <div class="lb-rank ${rankCls}">${rankLabel}</div>
        <div class="lb-info">
          <div class="lb-name">${escapeHtml(s.playerName)}</div>
          <div class="lb-meta">${cfg.icon || '📚'} ${s.category || 'General'} · <span class="diff-pill ${s.difficulty || 'medium'}" style="padding:2px 8px;font-size:0.65rem">${s.difficulty || 'medium'}</span> · ${s.timeTaken ? s.timeTaken + 's' : '-'}</div>
        </div>
        <div class="lb-score-wrap">
          <div class="lb-score">${s.score}</div>
          <div class="lb-total">${s.totalQuestions} Qs</div>
        </div>
      </div>`;
    }).join('');
  } catch {
    list.innerHTML = '<div class="lb-loading">Server offline — scores unavailable.</div>';
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// LOCAL FALLBACK QUESTIONS
// ═══════════════════════════════════════════════════════════════════════════
function getLocalFallback() {
  const pool = [
    { question:"What does `typeof null` return in JavaScript?", options:["null","undefined","object","string"], correctAnswer:2, explanation:"typeof null → 'object'. A known JS legacy bug.", difficulty:"easy", category:"JavaScript" },
    { question:"Which Python keyword defines a function?", options:["function","def","func","define"], correctAnswer:1, explanation:"'def' is the Python keyword for defining functions.", difficulty:"easy", category:"Python" },
    { question:"Time complexity of Binary Search?", options:["O(n)","O(n²)","O(log n)","O(1)"], correctAnswer:2, explanation:"Binary search halves the search space each step → O(log n).", difficulty:"easy", category:"DSA" },
    { question:"What does CSS `display: flex` enable?", options:["Grid layout","Flexbox layout","Absolute positioning","Z-index stacking"], correctAnswer:1, explanation:"display:flex enables the Flexbox layout model on a container.", difficulty:"easy", category:"Web Development" },
    { question:"What is Docker primarily used for?", options:["Version control","Containerizing applications","Database hosting","Cloud DNS"], correctAnswer:1, explanation:"Docker packages apps into portable containers.", difficulty:"easy", category:"DevOps" },
    { question:"What does `async/await` handle in JavaScript?", options:["Web workers","Promises in readable syntax","XSS prevention","Loop optimization"], correctAnswer:1, explanation:"async/await is syntactic sugar over Promises for cleaner async code.", difficulty:"medium", category:"JavaScript" },
    { question:"What is overfitting in ML?", options:["Too slow training","Good train accuracy but poor test accuracy","Too few layers","Missing labels"], correctAnswer:1, explanation:"Overfitting: model memorizes training data, fails on unseen data.", difficulty:"medium", category:"AI/ML" },
    { question:"What does `0.1 + 0.2 === 0.3` return in JavaScript?", options:["true","false","NaN","TypeError"], correctAnswer:1, explanation:"Floating-point: 0.1+0.2=0.30000000000000004 ≠ exactly 0.3", difficulty:"medium", category:"JavaScript" },
    { question:"What does SQL INNER JOIN return?", options:["All rows from both tables","Only matching rows","Left table only","Right table only"], correctAnswer:1, explanation:"INNER JOIN returns rows where the join condition matches in both tables.", difficulty:"medium", category:"Database" },
    { question:"What is the GIL in CPython?", options:["Garbage collection algo","Mutex preventing multiple threads executing bytecode simultaneously","Global variable lock","Distributed locking module"], correctAnswer:1, explanation:"GIL (Global Interpreter Lock) limits CPython to one thread at a time.", difficulty:"hard", category:"Python" },
    { question:"What is the worst-case time complexity of QuickSort?", options:["O(n log n)","O(n)","O(n²)","O(log n)"], correctAnswer:2, explanation:"QuickSort worst case O(n²) when pivot is always min/max.", difficulty:"hard", category:"DSA" },
    { question:"What is a closure in JavaScript?", options:["A type of loop","A function that remembers its lexical scope","An HTML element","An async pattern"], correctAnswer:1, explanation:"A closure is a function that retains access to its outer scope's variables.", difficulty:"medium", category:"JavaScript" },
    { question:"What does `git rebase` do?", options:["Merges branches with a merge commit","Reapplies commits on top of another base","Deletes old commits","Resets the working directory"], correctAnswer:1, explanation:"git rebase moves or replays commits on top of another branch's tip.", difficulty:"medium", category:"DevOps" },
    { question:"In SQL, what is a PRIMARY KEY?", options:["Any indexed column","A column uniquely identifying each row, cannot be NULL","A foreign key reference","A computed column"], correctAnswer:1, explanation:"PRIMARY KEY uniquely identifies each record and cannot contain NULL.", difficulty:"easy", category:"Database" },
    { question:"What is a REST API?", options:["A JavaScript library","An architectural style for web services using HTTP methods","A database protocol","A CSS framework"], correctAnswer:1, explanation:"REST (Representational State Transfer) uses HTTP verbs (GET/POST/PUT/DELETE) for web APIs.", difficulty:"easy", category:"Web Development" },
  ];
  const filtered = pool.filter(q => state.difficulty === 'hard' ? q.difficulty !== 'easy' : true);
  return (filtered.length >= 5 ? filtered : pool).sort(() => Math.random() - 0.5).slice(0, 10)
    .map(q => ({ ...q, difficulty: state.difficulty }));
}

// ═══════════════════════════════════════════════════════════════════════════
// PARTICLE CANVAS BACKGROUND
// ═══════════════════════════════════════════════════════════════════════════
(function initParticles() {
  const canvas = document.getElementById('particleCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let W, H, particles = [];

  function resize() {
    W = canvas.width  = window.innerWidth;
    H = canvas.height = window.innerHeight;
  }
  resize();
  window.addEventListener('resize', resize);

  const colors = ['#7c3aed','#06b6d4','#10b981','#8b5cf6','#f59e0b'];
  class Particle {
    constructor() { this.reset(true); }
    reset(init = false) {
      this.x = Math.random() * W;
      this.y = init ? Math.random() * H : (Math.random() > 0.5 ? -10 : H + 10);
      this.r  = Math.random() * 1.4 + 0.3;
      this.vx = (Math.random() - 0.5) * 0.25;
      this.vy = (Math.random() - 0.5) * 0.25;
      this.a  = Math.random() * 0.45 + 0.08;
      this.c  = colors[Math.floor(Math.random() * colors.length)];
    }
    step() {
      this.x += this.vx; this.y += this.vy;
      if (this.x < -20 || this.x > W+20 || this.y < -20 || this.y > H+20) this.reset();
    }
    draw() {
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
      ctx.fillStyle = this.c;
      ctx.globalAlpha = this.a;
      ctx.fill();
    }
  }

  for (let i = 0; i < 90; i++) particles.push(new Particle());

  function frame() {
    ctx.clearRect(0, 0, W, H);
    // Connection lines
    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const dx = particles[i].x - particles[j].x;
        const dy = particles[i].y - particles[j].y;
        const d  = Math.sqrt(dx*dx + dy*dy);
        if (d < 110) {
          ctx.beginPath();
          ctx.moveTo(particles[i].x, particles[i].y);
          ctx.lineTo(particles[j].x, particles[j].y);
          ctx.strokeStyle = '#7c3aed';
          ctx.globalAlpha = (1 - d / 110) * 0.07;
          ctx.lineWidth   = 0.5;
          ctx.stroke();
        }
      }
    }
    particles.forEach(p => { p.step(); p.draw(); });
    requestAnimationFrame(frame);
  }
  frame();
})();

import tkinter as tk
from tkinter import messagebox
import random
from game_data import data
from art import logo, vs

# -----------------------------
# Helper functions
# -----------------------------
def get_random_account(exclude=None):
    """Return a random account different from exclude."""
    account = random.choice(data)
    while exclude and account["name"] == exclude["name"]:
        account = random.choice(data)
    return account

def check_answer(guess, a_followers, b_followers):
    """Return True if guess is correct."""
    if a_followers > b_followers:
        return guess == "A"
    else:
        return guess == "B"

# -----------------------------
# Game functions
# -----------------------------
def start_game():
    """Start the game and set first accounts."""
    global account_a, account_b, score
    score = 0
    score_label.config(text=f"Score: {score}")
    account_a = get_random_account()
    account_b = get_random_account(exclude=account_a)
    update_display()

def update_display():
    """Update the labels with account info."""
    label_a_name.config(text=account_a["name"])
    label_a_desc.config(text=account_a["description"])
    label_a_country.config(text=f"From: {account_a['country']}")

    label_b_name.config(text=account_b["name"])
    label_b_desc.config(text=account_b["description"])
    label_b_country.config(text=f"From: {account_b['country']}")

    message_label.config(text="Who has more followers? Choose A or B!")

def make_guess(choice):
    """Handle when user clicks A or B."""
    global score, account_a, account_b

    a_followers = account_a["follower_count"]
    b_followers = account_b["follower_count"]

    correct = check_answer(choice, a_followers, b_followers)

    if correct:
        score += 1
        score_label.config(text=f"Score: {score}")
        message_label.config(text="✅ Correct! Next round loading...")
        account_a = account_b
        account_b = get_random_account(exclude=account_a)
        root.after(1000, update_display)
    else:
        messagebox.showinfo("Game Over", f"❌ Wrong! Final Score: {score}")
        start_game()

# -----------------------------
# GUI setup
# -----------------------------
root = tk.Tk()
root.title("🔥 Higher or Lower Game 🔥")
root.geometry("650x550")
root.config(bg="#1c1c2e")

# Title
title_label = tk.Label(root, text="🔥 Higher or Lower: Follower Game 🔥",
                       font=("Arial", 20, "bold"), fg="#ffcc00", bg="#1c1c2e")
title_label.pack(pady=15)

# ASCII art (optional)
ascii_label = tk.Label(root, text=logo + "\n" + vs, font=("Courier", 10),
                       fg="lightgreen", bg="#1c1c2e", justify="center")
ascii_label.pack(pady=5)

# Score label
score = 0
score_label = tk.Label(root, text=f"Score: {score}", font=("Arial", 14, "bold"),
                       fg="#00ff99", bg="#1c1c2e")
score_label.pack(pady=10)

# Frame for cards
frame = tk.Frame(root, bg="#1c1c2e")
frame.pack(pady=20)

# ---- Card A ----
frame_a = tk.Frame(frame, bg="#2b2b3c", padx=20, pady=20, relief="ridge", bd=3)
frame_a.grid(row=0, column=0, padx=20)
tk.Label(frame_a, text="Compare A", font=("Arial", 14, "bold"),
         fg="#00bcd4", bg="#2b2b3c").pack(pady=5)
label_a_name = tk.Label(frame_a, text="", font=("Arial", 13, "bold"), bg="#2b2b3c", fg="white")
label_a_name.pack()
label_a_desc = tk.Label(frame_a, text="", bg="#2b2b3c", fg="#bbb")
label_a_desc.pack()
label_a_country = tk.Label(frame_a, text="", bg="#2b2b3c", fg="#bbb")
label_a_country.pack()

# VS label
vs_label = tk.Label(frame, text="VS", font=("Arial", 20, "bold"),
                    fg="yellow", bg="#1c1c2e")
vs_label.grid(row=0, column=1, padx=10)

# ---- Card B ----
frame_b = tk.Frame(frame, bg="#2b2b3c", padx=20, pady=20, relief="ridge", bd=3)
frame_b.grid(row=0, column=2, padx=20)
tk.Label(frame_b, text="Against B", font=("Arial", 14, "bold"),
         fg="#f06292", bg="#2b2b3c").pack(pady=5)
label_b_name = tk.Label(frame_b, text="", font=("Arial", 13, "bold"), bg="#2b2b3c", fg="white")
label_b_name.pack()
label_b_desc = tk.Label(frame_b, text="", bg="#2b2b3c", fg="#bbb")
label_b_desc.pack()
label_b_country = tk.Label(frame_b, text="", bg="#2b2b3c", fg="#bbb")
label_b_country.pack()

# Message label
message_label = tk.Label(root, text="Who has more followers? Choose A or B!",
                         font=("Arial", 12, "bold"), fg="#ffeb3b", bg="#1c1c2e")
message_label.pack(pady=15)    

# Buttons
button_frame = tk.Frame(root, bg="#1c1c2e")
button_frame.pack(pady=10)
btn_a = tk.Button(button_frame, text="Choose A",
                  command=lambda: make_guess("A"),
                  bg="#00bcd4", fg="white", font=("Arial", 12, "bold"), width=12)
btn_a.grid(row=0, column=0, padx=20)
btn_b = tk.Button(button_frame, text="Choose B",
                  command=lambda: make_guess("B"),
                  bg="#f06292", fg="white", font=("Arial", 12, "bold"), width=12)
btn_b.grid(row=0, column=1, padx=20)

# Start the game once
start_game()

# Run GUI
root.mainloop()

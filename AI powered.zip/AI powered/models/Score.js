const mongoose = require('mongoose');

const scoreSchema = new mongoose.Schema({
  playerName: { type: String, required: true },
  score: { type: Number, required: true },
  totalQuestions: { type: Number, required: true },
  difficulty: { type: String, enum: ['easy', 'medium', 'hard'] },
  category: { type: String },
  language: { type: String, default: 'en' },
  timeTaken: { type: Number }, // seconds
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Score', scoreSchema);

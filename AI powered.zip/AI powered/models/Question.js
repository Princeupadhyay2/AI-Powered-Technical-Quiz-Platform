const mongoose = require('mongoose');

const questionSchema = new mongoose.Schema({
  question: { type: String, required: true },
  options: { type: [String], required: true },
  correctAnswer: { type: Number, required: true }, // index 0-3
  explanation: { type: String },
  difficulty: { type: String, enum: ['easy', 'medium', 'hard'], required: true },
  category: {
    type: String,
    enum: ['Python', 'JavaScript', 'Java', 'C++', 'DSA', 'Web Development', 'Database', 'AI/ML', 'DevOps'],
    required: true
  },
  language: { type: String, default: 'en' }, // en, hi, es, fr, etc.
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Question', questionSchema);

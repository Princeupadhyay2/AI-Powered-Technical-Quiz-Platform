const express = require('express');
const router = express.Router();
const Score = require('../models/Score');

// POST /api/scores — Save a score
router.post('/', async (req, res) => {
  try {
    const { playerName, score, totalQuestions, difficulty, category, language, timeTaken } = req.body;
    const newScore = new Score({ playerName, score, totalQuestions, difficulty, category, language, timeTaken });
    await newScore.save();
    res.json({ success: true, score: newScore });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/scores/history — Recent score history
router.get('/history', async (req, res) => {
  try {
    const { playerName, limit = 20 } = req.query;
    const filter = {};
    if (playerName && playerName !== 'Anonymous' && playerName !== 'Player') {
      filter.playerName = playerName;
    }
    const scores = await Score.find(filter).sort({ createdAt: -1 }).limit(Number(limit));
    res.json({ success: true, scores });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/scores/leaderboard — Top 10 scores
router.get('/leaderboard', async (req, res) => {
  try {
    const { difficulty, category } = req.query;
    const filter = {};
    if (difficulty) filter.difficulty = difficulty;
    if (category) filter.category = category;
    const scores = await Score.find(filter).sort({ score: -1, timeTaken: 1 }).limit(10);
    res.json({ success: true, scores });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;

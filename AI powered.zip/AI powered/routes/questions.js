const express = require('express');
const router = express.Router();
const { GoogleGenerativeAI } = require('@google/generative-ai');
const Question = require('../models/Question');

const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

// ─── AI Question Generator ───────────────────────────────────────────────────
async function generateQuestionsWithAI(category, difficulty, language, count = 5) {
  const langInstructions = {
    en: 'English',
    hi: 'Hindi (Devanagari script)',
    es: 'Spanish',
    fr: 'French',
    de: 'German',
    ja: 'Japanese'
  };
  const langName = langInstructions[language] || 'English';

  const prompt = `Generate ${count} multiple choice technical quiz questions about ${category} at ${difficulty} difficulty level.
Write the questions in ${langName}.
Return ONLY a valid JSON array with no extra text, no markdown, no code blocks.
Each element must have exactly these fields:
{
  "question": "the question text",
  "options": ["option A", "option B", "option C", "option D"],
  "correctAnswer": 0,
  "explanation": "brief explanation why this answer is correct"
}
correctAnswer must be the 0-based index (0, 1, 2, or 3) of the correct option.
Make questions practical and technical. For hard difficulty, include code snippets in questions.`;

  const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });
  const result = await model.generateContent(prompt);
  const text = result.response.text().trim();

  // Strip possible markdown code fences
  const cleaned = text.replace(/^```(?:json)?\n?/, '').replace(/\n?```$/, '').trim();
  return JSON.parse(cleaned);
}

// ─── GET /api/questions ───────────────────────────────────────────────────────
// Query params: category, difficulty, language, limit (default 10), useAI (bool)
router.get('/', async (req, res) => {
  try {
    const { category, difficulty, language = 'en', limit = 10, useAI = 'true' } = req.query;

    // Try DB first
    const filter = {};
    if (category) filter.category = category;
    if (difficulty) filter.difficulty = difficulty;
    if (language) filter.language = language;

    let questions = await Question.find(filter).limit(Number(limit));

    // If not enough in DB and AI is enabled, generate via Gemini
    if (questions.length < 5 && useAI === 'true' && process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'YOUR_GEMINI_API_KEY_HERE') {
      try {
        const cat = category || 'JavaScript';
        const diff = difficulty || 'medium';
        const aiQuestions = await generateQuestionsWithAI(cat, diff, language, 5);

        // Save generated questions to MongoDB
        const toSave = aiQuestions.map(q => ({
          ...q,
          category: cat,
          difficulty: diff,
          language
        }));
        const saved = await Question.insertMany(toSave, { ordered: false }).catch(() => []);
        questions = [...questions, ...saved.map(s => s.toObject ? s : s)];
      } catch (aiErr) {
        console.error('AI generation failed, using fallback:', aiErr.message);
        questions = getFallbackQuestions(category, difficulty, language);
      }
    } else if (questions.length < 5) {
      questions = getFallbackQuestions(category, difficulty, language);
    }

    // Shuffle and limit
    const shuffled = questions.sort(() => Math.random() - 0.5).slice(0, Number(limit));
    res.json({ success: true, questions: shuffled });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, error: err.message });
  }
});

// ─── POST /api/questions/generate ────────────────────────────────────────────
router.post('/generate', async (req, res) => {
  try {
    const { category = 'JavaScript', difficulty = 'medium', language = 'en', count = 5 } = req.body;

    if (!process.env.GEMINI_API_KEY || process.env.GEMINI_API_KEY === 'YOUR_GEMINI_API_KEY_HERE') {
      return res.json({ success: true, questions: getFallbackQuestions(category, difficulty, language) });
    }

    const aiQuestions = await generateQuestionsWithAI(category, difficulty, language, count);
    const toSave = aiQuestions.map(q => ({ ...q, category, difficulty, language }));
    await Question.insertMany(toSave, { ordered: false }).catch(() => {});
    res.json({ success: true, questions: aiQuestions });
  } catch (err) {
    console.error(err);
    res.status(500).json({ success: false, error: err.message, questions: getFallbackQuestions(req.body.category, req.body.difficulty, req.body.language) });
  }
});

// ─── Fallback static questions ────────────────────────────────────────────────
function getFallbackQuestions(category, difficulty, language) {
  const pool = [
    // JavaScript - Easy
    { question: "What does `typeof null` return in JavaScript?", options: ["null", "undefined", "object", "string"], correctAnswer: 2, explanation: "typeof null returns 'object' — this is a known bug in JavaScript from its early days.", difficulty: "easy", category: "JavaScript", language: "en" },
    { question: "Which method adds an element to the end of an array?", options: ["push()", "pop()", "shift()", "unshift()"], correctAnswer: 0, explanation: "push() adds one or more elements to the end of an array.", difficulty: "easy", category: "JavaScript", language: "en" },
    // JavaScript - Medium
    { question: "What is the output of `console.log(0.1 + 0.2 === 0.3)` in JavaScript?", options: ["true", "false", "NaN", "undefined"], correctAnswer: 1, explanation: "Due to floating point precision, 0.1 + 0.2 = 0.30000000000000004, not exactly 0.3.", difficulty: "medium", category: "JavaScript", language: "en" },
    { question: "What does the `async/await` syntax do in JavaScript?", options: ["Makes code run faster", "Handles promises more readable way", "Creates multithreading", "Prevents callback hell only"], correctAnswer: 1, explanation: "async/await is syntactic sugar over Promises that makes asynchronous code look synchronous.", difficulty: "medium", category: "JavaScript", language: "en" },
    // JavaScript - Hard
    { question: "What is the output?\n```js\nconst obj = { a: 1 };\nconst copy = { ...obj };\ncopy.a = 99;\nconsole.log(obj.a);\n```", options: ["99", "1", "undefined", "Error"], correctAnswer: 1, explanation: "Spread creates a shallow copy. Primitive values are copied by value, so modifying copy.a doesn't affect obj.a.", difficulty: "hard", category: "JavaScript", language: "en" },
    // Python - Easy
    { question: "Which of these is NOT a valid Python data type?", options: ["list", "tuple", "array", "dict"], correctAnswer: 2, explanation: "array is not a built-in Python type. Python has list, tuple, dict, set, etc. Arrays need `import array`.", difficulty: "easy", category: "Python", language: "en" },
    { question: "What does `len([1,2,3])` return?", options: ["2", "3", "4", "Error"], correctAnswer: 1, explanation: "len() returns the number of items. [1,2,3] has 3 elements.", difficulty: "easy", category: "Python", language: "en" },
    // Python - Medium
    { question: "What is a Python decorator?", options: ["A design pattern to add color to UI", "A function that modifies another function's behavior", "A type of list comprehension", "A way to declare constants"], correctAnswer: 1, explanation: "Decorators are functions that wrap other functions to extend their behavior without modifying their source code.", difficulty: "medium", category: "Python", language: "en" },
    { question: "What does `*args` mean in a Python function?", options: ["Required positional arguments", "Variable-length positional arguments", "Keyword-only arguments", "Default arguments"], correctAnswer: 1, explanation: "*args allows a function to accept any number of positional arguments as a tuple.", difficulty: "medium", category: "Python", language: "en" },
    // Python - Hard
    { question: "What is the GIL (Global Interpreter Lock) in CPython?", options: ["A tool for global variable locking", "A mutex that prevents multiple threads from executing Python bytecode simultaneously", "A garbage collection algorithm", "A module for distributed locking"], correctAnswer: 1, explanation: "The GIL is a mutex in CPython that ensures only one thread executes Python bytecode at a time, limiting true multi-core parallelism.", difficulty: "hard", category: "Python", language: "en" },
    // DSA
    { question: "What is the time complexity of binary search?", options: ["O(n)", "O(n²)", "O(log n)", "O(1)"], correctAnswer: 2, explanation: "Binary search halves the search space each iteration, giving O(log n) time complexity.", difficulty: "easy", category: "DSA", language: "en" },
    { question: "Which data structure uses LIFO (Last In, First Out)?", options: ["Queue", "Stack", "Linked List", "Heap"], correctAnswer: 1, explanation: "A stack uses LIFO — the last element pushed is the first to be popped.", difficulty: "easy", category: "DSA", language: "en" },
    { question: "What is the worst-case time complexity of QuickSort?", options: ["O(n log n)", "O(n)", "O(n²)", "O(log n)"], correctAnswer: 2, explanation: "QuickSort's worst case O(n²) occurs when the pivot is always the smallest or largest element.", difficulty: "medium", category: "DSA", language: "en" },
    // Web Dev
    { question: "What does CSS `flexbox` primarily control?", options: ["3D transformations", "One-dimensional layout (row or column)", "Two-dimensional grid layout", "Font rendering"], correctAnswer: 1, explanation: "Flexbox is a one-dimensional layout model that works along either a row or column axis.", difficulty: "easy", category: "Web Development", language: "en" },
    { question: "What is the purpose of `DOCTYPE` in HTML?", options: ["Defines the document type and version of HTML", "Adds meta tags", "Links CSS stylesheets", "Creates the document title"], correctAnswer: 0, explanation: "DOCTYPE declaration tells the browser which version of HTML the document is written in.", difficulty: "easy", category: "Web Development", language: "en" },
    // Database
    { question: "What does SQL `JOIN` do?", options: ["Deletes duplicate rows", "Combines rows from two or more tables", "Creates a new table", "Indexes columns for speed"], correctAnswer: 1, explanation: "JOIN combines rows from two or more tables based on a related column between them.", difficulty: "easy", category: "Database", language: "en" },
    { question: "What is an index in a database?", options: ["A primary key constraint", "A data structure that improves query speed", "A foreign key reference", "A stored procedure"], correctAnswer: 1, explanation: "An index is a data structure that allows faster retrieval of records from a table at the cost of additional storage.", difficulty: "medium", category: "Database", language: "en" },
    // AI/ML
    { question: "What is overfitting in machine learning?", options: ["Model performs well on training data but poorly on new data", "Model is too simple to capture patterns", "Model trains too slowly", "Model has too many training examples"], correctAnswer: 0, explanation: "Overfitting occurs when a model memorizes training data noise and fails to generalize to unseen data.", difficulty: "medium", category: "AI/ML", language: "en" },
    // DevOps
    { question: "What is Docker used for?", options: ["Version control", "Database management", "Containerizing applications", "Cloud DNS management"], correctAnswer: 2, explanation: "Docker packages applications and their dependencies into containers for consistent deployment across environments.", difficulty: "easy", category: "DevOps", language: "en" },
    { question: "What is CI/CD?", options: ["Code Integration / Code Deployment", "Continuous Integration / Continuous Delivery", "Cloud Infrastructure / Cloud Delivery", "Container Integration / Container Deployment"], correctAnswer: 1, explanation: "CI/CD stands for Continuous Integration and Continuous Delivery/Deployment — automating build, test, and deploy pipelines.", difficulty: "easy", category: "DevOps", language: "en" },
  ];

  let filtered = pool;
  if (category) filtered = filtered.filter(q => q.category === category);
  if (difficulty) filtered = filtered.filter(q => q.difficulty === difficulty);
  if (filtered.length < 5) filtered = pool;
  return filtered.sort(() => Math.random() - 0.5).slice(0, 10);
}

module.exports = router;
